/* src/components/CopilotSovereignAI.tsx */
import React, { useState, useEffect, useRef } from 'react';
import {
  Bot,
  ShieldCheck,
  Terminal,
  Sparkles,
  Maximize2,
  Minimize2,
  X,
  Play,
  Pause,
  Download,
  RefreshCw,
  Send,
  Activity,
  Lock,
  FolderSync,
  CheckCircle2,
  GitBranch,
  Layers,
  Zap,
  Scale,
  FileDown,
  Cpu,
  HeartPulse,
  Copy,
  Check,
} from 'lucide-react';
import { safeCopyToClipboard } from '../utils/clipboard';
import {
  copilotAssistantService,
  CopilotAssistantState,
  CANONICAL_FORENSIC_IDENTITY_METADATA,
  CANONICAL_16_FORENSIC_STAGES,
  ForensicPipelineStageItem,
} from '../services/copilotAssistantService';
import { githubSyncService, GitHubSyncState } from '../services/githubSyncService';
import { useSystemState } from '../hooks/useSystemState';
import { playTone, playAuditChime } from './AudioSynthesizer';
import { CopilotAutonomyNodePanel } from './copilot/CopilotAutonomyNodePanel';
import { INITIAL_16_AUDIT_STEPS, exportFull16StepSummaryPDF } from './ForensicAuditStepper';
import { ViewType } from '../types';

export interface CopilotSovereignAIProps {
  isOpen?: boolean;
  onClose?: () => void;
  onOpen?: () => void;
  onNavigate?: (view: ViewType) => void;
  floatingActions?: React.ReactNode;
}

interface SyncedFileManifestItem {
  path: string;
  category: 'CORE' | 'SECURITY' | 'COPILOT' | 'WORKFLOW' | 'SSOT';
  shaShort: string;
  status: 'UPDATED' | 'SYNCING' | 'VERIFIED';
  sizeKb: string;
  descriptionTh: string;
}

const CANONICAL_SYNCED_FILES: SyncedFileManifestItem[] = [
  {
    path: 'src/App.tsx',
    category: 'CORE',
    shaShort: '909ab814',
    status: 'UPDATED',
    sizeKb: '188.0 KB',
    descriptionTh: 'Sovereign World Engine Master Control Plane & Routing',
  },
  {
    path: 'src/components/views/SecurityView.tsx',
    category: 'SECURITY',
    shaShort: 'e3b0c442',
    status: 'UPDATED',
    sizeKb: '72.4 KB',
    descriptionTh: '10-Node HSM Quorum Monitor, Crimson Pulse, Gauge & Auto-Heal',
  },
  {
    path: 'src/components/CopilotSovereignAI.tsx',
    category: 'COPILOT',
    shaShort: '54783c5a',
    status: 'UPDATED',
    sizeKb: '38.4 KB',
    descriptionTh: 'Copilot Sovereign AI v7.0 Neural Oracle + 16-Step Auto-Pilot Engine',
  },
  {
    path: 'src/components/ForensicAuditStepper.tsx',
    category: 'SECURITY',
    shaShort: '16stg909',
    status: 'UPDATED',
    sizeKb: '56.4 KB',
    descriptionTh: '16-Step Forensic Audit Pipeline Execution Matrix (STG-01..16)',
  },
  {
    path: 'src/components/copilot/CopilotAutonomyNodePanel.tsx',
    category: 'COPILOT',
    shaShort: '849205f9',
    status: 'UPDATED',
    sizeKb: '50.4 KB',
    descriptionTh: 'Autonomy Node, 60-Min Entropy Timeline, Cryo-Burst & Swarm',
  },
  {
    path: 'src/services/copilotAssistantService.ts',
    category: 'COPILOT',
    shaShort: '40202bf9',
    status: 'UPDATED',
    sizeKb: '52.2 KB',
    descriptionTh: '5-Layer Copilot Reflex, Closed-Loop Auto-Pilot & 16-Step Matrix',
  },
  {
    path: 'src/services/githubSyncService.ts',
    category: 'SSOT',
    shaShort: '14902ac7',
    status: 'UPDATED',
    sizeKb: '14.1 KB',
    descriptionTh: 'GitHub Branch Parity, Merkle Checksum & Commit Stream',
  },
  {
    path: 'src/config/sovereign.config.ts',
    category: 'SSOT',
    shaShort: '8492020a',
    status: 'UPDATED',
    sizeKb: '6.8 KB',
    descriptionTh: 'Genesis Block #849202 & Δ0.00% Zero-Drift Canonical Config',
  },
  {
    path: 'src/data/canonicalData.ts',
    category: 'SSOT',
    shaShort: 'f1952048',
    status: 'UPDATED',
    sizeKb: '24.2 KB',
    descriptionTh: '14,902 Verified Seals, 10/10 REAL_HSM & ETDA Legal Invariants',
  },
  {
    path: 'scripts/zyrquen-security-gate.py',
    category: 'SECURITY',
    shaShort: '22gate00',
    status: 'UPDATED',
    sizeKb: '7.0 KB',
    descriptionTh: '22/22 Master Verification Gates (Node 22, PQC, Zero-Any)',
  },
  {
    path: '.github/workflows/ci.yml',
    category: 'WORKFLOW',
    shaShort: 'ci22node',
    status: 'UPDATED',
    sizeKb: '2.4 KB',
    descriptionTh: 'GitHub Actions CI Matrix (Node 22 + Sparse-Checkout Clean)',
  },
  {
    path: '.github/workflows/deploy.yml',
    category: 'WORKFLOW',
    shaShort: 'dep22ghp',
    status: 'UPDATED',
    sizeKb: '2.6 KB',
    descriptionTh: 'GitHub Pages Production Deployment Pipeline (Node 22)',
  },
  {
    path: 'README.md',
    category: 'CORE',
    shaShort: 'rdm84920',
    status: 'UPDATED',
    sizeKb: '6.2 KB',
    descriptionTh: 'Root Repository Description & Sovereign Architecture Guide (main)',
  },
  {
    path: 'public/README.md',
    category: 'WORKFLOW',
    shaShort: 'ghp84920',
    status: 'UPDATED',
    sizeKb: '2.4 KB',
    descriptionTh: 'GitHub Pages (gh-pages) Branch Description & Live Artifact README',
  },
];

const V7_NEURAL_ORACLE_LAYERS = [
  {
    layerId: 'L1',
    title: 'Copilot Autonomy Node',
    descTh: 'เฝ้าระวัง Sovereign Ledger ตลอด 24/7 และแจ้งเตือนความเบี่ยงเบนอัตโนมัติ',
    latency: '0.11ms',
    metric: '24/7 Active',
    query: 'ตรวจสอบสถานะ L1 Copilot Autonomy Node และ SSoT Ledger',
  },
  {
    layerId: 'L2',
    title: 'Copilot Memory Mesh',
    descTh: 'ดัชนีความจำหลักฐาน 14,902 Seals และแยกกักกัน 80 Quarantine Seals',
    latency: '0.12ms',
    metric: '14,902 Seals',
    query: 'ตรวจสอบ L2 Memory Mesh 14,902 Seals และ 80 Quarantine',
  },
  {
    layerId: 'L3',
    title: '3D Hologram Continuum',
    descTh: 'ซิงค์การแสดงผล Sphere ↔ Tree ↔ Hologram แบบเรียลไทม์ 60fps',
    latency: '0.14ms',
    metric: '60 FPS Sync',
    query: 'สลับโหมด Sphere และตรวจสอบ 3D Hologram Continuum',
  },
  {
    layerId: 'L4',
    title: 'Sentinel Reflex Fail-Closed',
    descTh: 'สกัดกั้นความเสี่ยง Risk ≥ 0.85 ทันทีด้วย HTTP 423 Locked Quarantine',
    latency: '0.09ms',
    metric: 'Risk < 0.85',
    query: 'รัน Sentinel Sweep ตรวจสอบระบบป้องกัน Fail-Closed',
  },
  {
    layerId: 'L5',
    title: 'Thai Semantic Ultra DSL',
    descTh: 'ประมวลผลคำสั่งภาษาไทยและกฎหมายดิจิทัล ETDA / PDPA เชิงลึก',
    latency: '0.13ms',
    metric: 'Thai/EN Native',
    query: 'ขอทราบกฎเหล็ก coding rules ของระบบ',
  },
  {
    layerId: 'L6',
    title: 'NIST PQC Lattice Verifier',
    descTh: 'ตรวจสอบลายมือชื่อควอนตัม ML-DSA-87 (Dilithium-5) & 10/10 REAL_HSM',
    latency: '0.10ms',
    metric: 'FIPS 204 L4',
    query: 'ตรวจสอบ PQC Dilithium-5 และ 10/10 REAL_HSM Quorum',
  },
  {
    layerId: 'L7',
    title: 'Court-Annex v2 Judicial Oracle',
    descTh: 'รับรองสำนวนศาล แบบ จพ.๐๓ ครบ 8/8 Test Vectors & ISO/IEC 27037',
    latency: '0.12ms',
    metric: '8/8 Vectors',
    query: 'ตรวจสอบรายงานนิติวิทยาศาสตร์ 16 ขั้นตอน และ PQC Dilithium-5',
  },
] as const;

export const CopilotSovereignAI: React.FC<CopilotSovereignAIProps> = ({
  isOpen,
  onClose,
  onOpen,
  onNavigate,
  floatingActions,
}) => {
  const [isMinimized, setIsMinimized] = useState(false);
  const [isExpanded, setIsExpanded] = useState(false);
  const [activeTab, setActiveTab] = useState<'dialogue' | 'oracle7' | 'forensic16' | 'autonomy' | 'files'>('dialogue');
  const [copiedMsgId, setCopiedMsgId] = useState<string | null>(null);
  const [holoMode, setHoloMode] = useState<'hologram' | 'sphere' | 'tree'>('sphere');
  const [isSpinning, setIsSpinning] = useState(true);
  const [inputMsg, setInputMsg] = useState('');
  const [isSyncingAllFiles, setIsSyncingAllFiles] = useState(false);
  const [isAutoTuningSweep, setIsAutoTuningSweep] = useState(false);
  const [sweepingStageIdx, setSweepingStageIdx] = useState<number | null>(null);
  const [selectedStage, setSelectedStage] = useState<ForensicPipelineStageItem>(
    CANONICAL_16_FORENSIC_STAGES[0]
  );
  const [syncedFiles, setSyncedFiles] = useState<SyncedFileManifestItem[]>(CANONICAL_SYNCED_FILES);
  const [lastFullSyncTime, setLastFullSyncTime] = useState<string>(
    new Date().toLocaleTimeString('th-TH', { hour12: false })
  );
  const [neuralWavePhase, setNeuralWavePhase] = useState<number>(0);

  const [copilotState, setCopilotState] = useState<CopilotAssistantState>(
    copilotAssistantService.getState()
  );
  const [gitSyncState, setGitSyncState] = useState<GitHubSyncState>(
    githubSyncService.getState()
  );
  const systemState = useSystemState();
  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const unsubCopilot = copilotAssistantService.subscribe((s) => {
      setCopilotState(s);
    });
    const unsubGit = githubSyncService.subscribe((g) => {
      setGitSyncState(g);
    });
    return () => {
      unsubCopilot();
      unsubGit();
    };
  }, []);

  // Lively Neural Heartbeat Wave Animation
  useEffect(() => {
    if (isMinimized) return;
    const timer = setInterval(() => {
      setNeuralWavePhase((prev) => (prev + 1) % 360);
    }, 180);
    return () => clearInterval(timer);
  }, [isMinimized]);

  useEffect(() => {
    if (isOpen !== undefined) {
      setIsMinimized(!isOpen);
    }
  }, [isOpen]);

  useEffect(() => {
    if (!isMinimized && activeTab === 'dialogue') {
      chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [copilotState.chatHistory, isMinimized, activeTab]);

  const handlePullAndSyncAllFiles = async () => {
    if (isSyncingAllFiles) return;
    setIsSyncingAllFiles(true);
    playTone(680, 0.05);

    setSyncedFiles((prev) =>
      prev.map((item) => ({
        ...item,
        status: 'SYNCING',
      }))
    );

    await githubSyncService.forceRemoteResync();
    copilotAssistantService.runSentinelReflexAudit();
    copilotAssistantService.runPQCAudit();

    const updatedTime = new Date().toLocaleTimeString('th-TH', { hour12: false });
    setLastFullSyncTime(updatedTime);
    setSyncedFiles(
      CANONICAL_SYNCED_FILES.map((item) => ({
        ...item,
        status: 'UPDATED',
      }))
    );
    setIsSyncingAllFiles(false);
    playAuditChime();
  };

  const handleAutoTuneAll16Stages = async () => {
    if (isAutoTuningSweep) return;
    setIsAutoTuningSweep(true);
    playTone(740, 0.06);

    for (let i = 0; i < CANONICAL_16_FORENSIC_STAGES.length; i += 4) {
      setSweepingStageIdx(i);
      await new Promise((r) => setTimeout(r, 90));
    }

    await copilotAssistantService.runAutoTune16StageSweep();
    const updatedTime = new Date().toLocaleTimeString('th-TH', { hour12: false });
    setLastFullSyncTime(updatedTime);
    setSweepingStageIdx(null);
    setIsAutoTuningSweep(false);
    playAuditChime();
  };

  const handleToggleAutoPilot = () => {
    playTone(660, 0.05);
    copilotAssistantService.toggleAutoPilot();
  };

  const handleSend = async (customQuery?: string) => {
    const query = (customQuery ?? inputMsg).trim();
    if (!query) return;
    if (!customQuery) {
      setInputMsg('');
    }
    playTone(640, 0.04);
    await copilotAssistantService.processUserQuery(query);
  };

  const handleMinimize = () => {
    setIsMinimized(true);
    if (onClose) onClose();
  };

  const handleDownloadSnapshot = () => {
    playAuditChime();
    copilotAssistantService.triggerSnapshotDownload();
  };

  const handleExport16StagePdf = () => {
    playAuditChime();
    exportFull16StepSummaryPDF(INITIAL_16_AUDIT_STEPS);
  };

  const handleHoloModeChange = (mode: 'hologram' | 'sphere' | 'tree') => {
    playTone(720, 0.04);
    setHoloMode(mode);
    if (mode === 'sphere') {
      copilotAssistantService.setUIRendererMode('SPHERE');
    } else if (mode === 'tree') {
      copilotAssistantService.setUIRendererMode('TREE');
    } else {
      copilotAssistantService.setUIRendererMode('CLUSTERED_3D');
    }
  };

  const handleToggleSpin = () => {
    playTone(580, 0.04);
    const next = !isSpinning;
    setIsSpinning(next);
    copilotAssistantService.toggleUISpin(next);
  };

  if (isMinimized) {
    return null;
  }

  const activeLiveStage =
    CANONICAL_16_FORENSIC_STAGES[
      sweepingStageIdx !== null ? sweepingStageIdx : copilotState.activeForensicStageIndex
    ] || CANONICAL_16_FORENSIC_STAGES[0];

  // Dynamic SVG path for Lively Neural Heartbeat
  const waveY1 = 10 + Math.sin((neuralWavePhase * Math.PI) / 180) * 6;
  const waveY2 = 10 - Math.cos((neuralWavePhase * Math.PI) / 180) * 6;
  const neuralWavePath = `M 0 10 Q 15 ${waveY1.toFixed(1)}, 30 10 T 60 ${waveY2.toFixed(1)} T 90 10`;

  return (
    <aside
      data-testid="copilot-sovereign-ai-panel"
      className={`fixed z-50 transition-all duration-300 ${
        isExpanded
          ? 'inset-2 sm:inset-4 md:inset-6 max-w-full h-[calc(100vh-1rem)] sm:h-[calc(100vh-2rem)]'
          : 'bottom-14 right-2 left-2 sm:left-auto sm:right-4 sm:w-[500px] md:w-[540px] h-[84vh] max-h-[84vh]'
      } flex flex-col bg-slate-950/95 backdrop-blur-2xl border border-cyan-500/45 rounded-2xl shadow-2xl shadow-cyan-950/80 overflow-hidden`}
    >
      {/* Top Header with Lively Neural Pulse */}
      <div className="flex items-center justify-between px-3.5 py-2.5 bg-gradient-to-r from-cyan-950/95 via-slate-900 to-indigo-950/95 border-b border-cyan-800/50 shrink-0">
        <div className="flex items-center gap-2.5 min-w-0">
          <div className="relative p-1.5 rounded-xl bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shrink-0 shadow-[0_0_14px_rgba(6,182,212,0.35)]">
            <Bot className="w-4 h-4 animate-pulse" />
            <span className="absolute -top-0.5 -right-0.5 w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
            <span className="absolute -top-0.5 -right-0.5 w-2 h-2 rounded-full bg-emerald-400" />
          </div>
          <div className="truncate">
            <div className="flex items-center gap-1.5 flex-wrap">
              <span className="text-xs font-black text-white tracking-wide">
                COPILOT SOVEREIGN AI
              </span>
              <span className="px-1.5 py-0.5 text-[9px] font-bold rounded bg-cyan-500/20 text-cyan-300 border border-cyan-400/40">
                v7.0 ULTRA LIVE
              </span>
              <button
                type="button"
                data-testid="btn-copilot-autopilot-toggle"
                onClick={handleToggleAutoPilot}
                className={`px-1.5 py-0.5 text-[9px] font-bold rounded border flex items-center gap-1 transition-all cursor-pointer ${
                  copilotState.autoPilotActive
                    ? 'bg-emerald-500/25 text-emerald-200 border-emerald-400/60 shadow-[0_0_10px_rgba(16,185,129,0.3)]'
                    : 'bg-slate-800 text-slate-400 border-slate-700'
                }`}
                title="เปิด/ปิด โหมดปรับจูนอัตโนมัติ (Real-Time Autonomous Self-Tuning)"
              >
                <HeartPulse className={`w-2.5 h-2.5 ${copilotState.autoPilotActive ? 'text-emerald-300 animate-pulse' : 'text-slate-400'}`} />
                <span>{copilotState.autoPilotActive ? 'AUTO-PILOT: ON' : 'AUTO-PILOT: OFF'}</span>
              </button>
            </div>
            <p className="text-[10px] text-slate-300 truncate font-mono mt-0.5">
              Epoch #{systemState.sealedBlock.toLocaleString()} • 99.47% Integrity • นายยุทธภูมิ พากเพียร (#EP-SOVEREIGN-01)
            </p>
          </div>
        </div>

        <div className="flex items-center gap-1 shrink-0">
          {floatingActions}
          <button
            type="button"
            onClick={() => setIsExpanded(!isExpanded)}
            className="p-1.5 rounded-lg text-slate-300 hover:text-white hover:bg-slate-800/80 transition-colors cursor-pointer"
            title={isExpanded ? 'ย่อขนาด' : 'ขยายเต็มจอ'}
          >
            {isExpanded ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
          </button>
          <button
            type="button"
            onClick={handleMinimize}
            className="p-1.5 rounded-lg text-slate-300 hover:text-rose-400 hover:bg-rose-950/40 transition-colors cursor-pointer"
            title="พับเก็บ"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Navigation Tabs - Mobile-First Touch Target Compact Design */}
      <div className="flex items-center justify-between px-2 py-1 bg-slate-900/90 border-b border-slate-800 text-[11px] shrink-0">
        <div className="flex items-center gap-1 overflow-x-auto no-scrollbar py-0.5 w-full">
          <button
            type="button"
            onClick={() => setActiveTab('dialogue')}
            className={`px-2 py-1 rounded-lg font-bold flex items-center gap-1.5 transition-all cursor-pointer text-[10px] sm:text-[11px] shrink-0 ${
              activeTab === 'dialogue'
                ? 'bg-cyan-500/25 text-cyan-200 border border-cyan-500/50 shadow-[0_0_10px_rgba(6,182,212,0.2)]'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Sparkles className="w-3 h-3 text-cyan-400" />
            <span>Dialogue &amp; Auto-Tune</span>
          </button>

          <button
            type="button"
            data-testid="tab-copilot-oracle-v7"
            onClick={() => setActiveTab('oracle7')}
            className={`px-2 py-1 rounded-lg font-bold flex items-center gap-1.5 transition-all cursor-pointer text-[10px] sm:text-[11px] shrink-0 ${
              activeTab === 'oracle7'
                ? 'bg-purple-500/25 text-purple-200 border border-purple-500/50 shadow-[0_0_10px_rgba(168,85,247,0.25)]'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Cpu className="w-3 h-3 text-purple-400" />
            <span>v7.0 Oracle (7L)</span>
          </button>

          <button
            type="button"
            data-testid="tab-copilot-forensic-16"
            onClick={() => setActiveTab('forensic16')}
            className={`px-2 py-1 rounded-lg font-bold flex items-center gap-1.5 transition-all cursor-pointer text-[10px] sm:text-[11px] shrink-0 ${
              activeTab === 'forensic16'
                ? 'bg-amber-500/25 text-amber-200 border border-amber-500/50 shadow-[0_0_10px_rgba(245,158,11,0.2)]'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Scale className="w-3 h-3 text-amber-400" />
            <span>16 ขั้นตอน (16/16)</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('autonomy')}
            className={`px-2 py-1 rounded-lg font-bold flex items-center gap-1.5 transition-all cursor-pointer text-[10px] sm:text-[11px] shrink-0 ${
              activeTab === 'autonomy'
                ? 'bg-cyan-500/25 text-cyan-200 border border-cyan-500/50 shadow-[0_0_10px_rgba(6,182,212,0.2)]'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Activity className="w-3 h-3 text-cyan-400" />
            <span>Autonomy</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('files')}
            className={`px-2 py-1 rounded-lg font-bold flex items-center gap-1.5 transition-all cursor-pointer text-[10px] sm:text-[11px] shrink-0 ${
              activeTab === 'files'
                ? 'bg-emerald-500/25 text-emerald-200 border border-emerald-500/50 shadow-[0_0_10px_rgba(16,185,129,0.2)]'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <GitBranch className="w-3 h-3 text-emerald-400" />
            <span>GitHub Sync</span>
          </button>
        </div>
      </div>

      {/* Lively Neural Heartbeat & Active Stage Strip */}
      <div className="flex items-center justify-between gap-2 px-2.5 py-1.5 bg-slate-950 border-b border-slate-800/80 text-[10px] font-mono shrink-0">
        <div className="flex items-center gap-2 min-w-0">
          <svg viewBox="0 0 90 20" className="w-14 h-4 shrink-0">
            <path
              d={neuralWavePath}
              fill="none"
              stroke={copilotState.autoPilotActive ? '#10b981' : '#64748b'}
              strokeWidth="2"
              strokeLinecap="round"
            />
          </svg>
          <span className="px-1.5 py-0.5 rounded bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 font-bold shrink-0">
            {activeLiveStage.stageId}
          </span>
          <span className="text-cyan-200 truncate" title={activeLiveStage.title}>
            {activeLiveStage.title}
          </span>
        </div>

        <div className="flex items-center gap-1.5 shrink-0">
          <span className="px-1.5 py-0.5 rounded bg-slate-900 border border-slate-800 text-emerald-300 tabular-nums">
            Δ{systemState.ssotMutationDrift}
          </span>
          <button
            type="button"
            data-testid="btn-copilot-autotune-16"
            onClick={handleAutoTuneAll16Stages}
            disabled={isAutoTuningSweep}
            className="px-2 py-0.5 rounded bg-gradient-to-r from-emerald-600/80 to-cyan-600/80 hover:from-emerald-500 hover:to-cyan-500 text-white border border-emerald-400/50 font-bold flex items-center gap-1 cursor-pointer transition-all"
            title="สั่ง Copilot ปรับจูนสมดุลและตรวจสอบครบทั้ง 16 ขั้นตอนอัตโนมัติ"
          >
            <Zap className={`w-2.5 h-2.5 text-amber-300 ${isAutoTuningSweep ? 'animate-spin' : ''}`} />
            <span>{isAutoTuningSweep ? 'กำลังปรับจูน...' : 'ปรับจูนอัตโนมัติ'}</span>
          </button>
        </div>
      </div>

      {/* Hologram Continuum Mode Bar */}
      <div className="flex items-center justify-between gap-2 px-2.5 py-1.5 bg-slate-900/60 text-[11px] border-b border-slate-800/70 shrink-0 flex-wrap">
        <div className="flex items-center gap-1">
          {(['hologram', 'sphere', 'tree'] as const).map((mode) => (
            <button
              key={mode}
              type="button"
              onClick={() => handleHoloModeChange(mode)}
              className={`px-2 py-0.5 rounded capitalize text-[10px] font-semibold transition-all cursor-pointer whitespace-nowrap ${
                holoMode === mode
                  ? 'bg-cyan-500/30 text-cyan-200 border border-cyan-400/50'
                  : 'bg-slate-800/60 text-slate-400 hover:text-slate-200'
              }`}
            >
              {mode}
            </button>
          ))}
          <button
            type="button"
            onClick={handleToggleSpin}
            className="px-2 py-0.5 rounded bg-amber-950/60 border border-amber-500/40 text-amber-300 text-[10px] font-semibold flex items-center gap-1 shrink-0 cursor-pointer whitespace-nowrap"
          >
            {isSpinning ? <Pause className="w-2.5 h-2.5" /> : <Play className="w-2.5 h-2.5" />}
            <span>{isSpinning ? 'Pause Spin' : 'Resume Spin'}</span>
          </button>
        </div>

        <span className="text-[10px] font-mono text-slate-400 truncate">
          14,902 Seals • 80 Quarantine • 10/10 REAL_HSM
        </span>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 p-2.5 overflow-y-auto space-y-2.5 bg-slate-950 font-mono text-[11px] custom-scrollbar">
        {activeTab === 'dialogue' && (
          <>
            {/* Autonomous Self-Tuning & 16-Stage Pipeline Summary Card */}
            <div className="p-3 rounded-xl bg-gradient-to-br from-slate-900/95 via-slate-900/90 to-cyan-950/35 border border-cyan-500/35 space-y-2.5">
              <div className="flex items-center justify-between gap-2 border-b border-slate-800 pb-1.5">
                <span className="flex items-center gap-1.5 text-[10.5px] font-bold text-cyan-300">
                  <Cpu className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
                  <span>ระบบปรับจูนสมดุลอัตโนมัติ (Autonomous Self-Tuning Engine)</span>
                </span>
                <span className="px-2 py-0.5 rounded bg-emerald-500/20 border border-emerald-400/40 text-[9.5px] font-bold text-emerald-300 tabular-nums">
                  16/16 STAGES PASSED (100%)
                </span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5 text-[10px]">
                <div className="p-1.5 rounded-lg bg-slate-950/80 border border-slate-800">
                  <span className="text-slate-400 block text-[9px]">Integrity Score</span>
                  <span className="text-emerald-300 font-bold tabular-nums">99.47% (14,902 Seals)</span>
                </div>
                <div className="p-1.5 rounded-lg bg-slate-950/80 border border-slate-800">
                  <span className="text-slate-400 block text-[9px]">Chamber 02 Quarantine</span>
                  <span className="text-amber-300 font-bold tabular-nums">80 Seals Isolated</span>
                </div>
                <div className="p-1.5 rounded-lg bg-slate-950/80 border border-slate-800">
                  <span className="text-slate-400 block text-[9px]">SSoT &amp; GitHub Sync</span>
                  <span className="text-cyan-300 font-bold tabular-nums">Δ0.00% Zero Drift</span>
                </div>
                <div className="p-1.5 rounded-lg bg-slate-950/80 border border-slate-800">
                  <span className="text-slate-400 block text-[9px]">Phoenix Auto-Heal</span>
                  <span className="text-emerald-300 font-bold tabular-nums">35.80 ms (&le;142ms)</span>
                </div>
              </div>

              {/* 16-Stage Visual Pulse Bar */}
              <div className="space-y-1">
                <div className="flex items-center justify-between text-[9.5px] text-slate-300">
                  <span className="truncate">{copilotState.lastAutoTuneSummary}</span>
                  <span className="text-emerald-400 font-bold shrink-0 ml-2">
                    Auto-Tunes: #{copilotState.autoTuneCount}
                  </span>
                </div>
                <div className="grid grid-cols-16 gap-0.5 p-1 rounded-lg bg-slate-950 border border-slate-800">
                  {CANONICAL_16_FORENSIC_STAGES.map((stg, idx) => {
                    const isCurrent =
                      (sweepingStageIdx !== null ? sweepingStageIdx : copilotState.activeForensicStageIndex) ===
                      idx;
                    return (
                      <button
                        key={stg.stageId}
                        type="button"
                        onClick={() => {
                          setSelectedStage(stg);
                          setActiveTab('forensic16');
                        }}
                        title={`${stg.stageId}: ${stg.title} (${stg.status})`}
                        className={`h-2.5 rounded-sm transition-all cursor-pointer ${
                          isCurrent
                            ? 'bg-cyan-300 shadow-[0_0_8px_#22d3ee] scale-y-125'
                            : 'bg-emerald-500/80 hover:bg-emerald-400'
                        }`}
                      />
                    );
                  })}
                </div>
              </div>

              <div className="flex items-center gap-2 pt-0.5">
                <button
                  type="button"
                  onClick={handleAutoTuneAll16Stages}
                  disabled={isAutoTuningSweep}
                  className="flex-1 py-1.5 px-3 rounded-lg bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-400/50 text-emerald-200 font-sans font-bold text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Zap className={`w-3.5 h-3.5 text-amber-300 ${isAutoTuningSweep ? 'animate-spin' : ''}`} />
                  <span>ปรับจูนและตรวจพิสูจน์ 16 ขั้นตอนอัตโนมัติ (Auto-Tune Now)</span>
                </button>
                <button
                  type="button"
                  onClick={() => setActiveTab('forensic16')}
                  className="py-1.5 px-2.5 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-amber-300 font-sans font-bold text-xs transition-colors cursor-pointer whitespace-nowrap"
                >
                  รายงาน 16 ขั้นตอน
                </button>
              </div>
            </div>

            {/* Sentinel Sweep & Active Chat Stream */}
            <div className="p-3 rounded-xl bg-slate-900/90 border border-cyan-500/30 space-y-2.5">
              <div className="flex items-center justify-between text-[10px] text-amber-400 border-b border-slate-800 pb-1.5">
                <span className="flex items-center gap-1.5 font-bold">
                  <Terminal className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Sentinel Sweep v7.0 • Neural Oracle Dialogue &amp; Reflex</span>
                </span>
                <span className="text-slate-400 tabular-nums">{lastFullSyncTime}</span>
              </div>

              <div className="space-y-2 max-h-64 overflow-y-auto pr-1 custom-scrollbar">
                {copilotState.chatHistory.map((item) => (
                  <div
                    key={item.id}
                    className={`p-2.5 rounded-xl border text-[11px] leading-relaxed font-sans space-y-2 ${
                      item.sender === 'user'
                        ? 'bg-cyan-950/50 border-cyan-500/40 text-cyan-100 ml-4'
                        : 'bg-slate-950/90 border-slate-800 text-slate-200'
                    }`}
                  >
                    <div className="flex items-center justify-between text-[9.5px] text-slate-400 font-mono mb-1">
                      <span className="font-bold text-cyan-300">
                        {item.sender === 'user' ? 'Sovereign Architect' : 'Copilot Sovereign v7.0'}
                      </span>
                      <div className="flex items-center gap-1.5">
                        <span>{item.timestamp.slice(11, 19)}</span>
                        <button
                          type="button"
                          onClick={async () => {
                            playTone(640, 0.02);
                            const ok = await safeCopyToClipboard(item.message);
                            if (ok) {
                              setCopiedMsgId(item.id);
                              setTimeout(() => setCopiedMsgId(null), 1500);
                            }
                          }}
                          className="p-0.5 rounded bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-cyan-300 cursor-pointer"
                          title="คัดลอกข้อความ"
                        >
                          {copiedMsgId === item.id ? (
                            <Check className="w-2.5 h-2.5 text-emerald-400" />
                          ) : (
                            <Copy className="w-2.5 h-2.5" />
                          )}
                        </button>
                      </div>
                    </div>
                    <p className="whitespace-pre-wrap">{item.message}</p>

                    {/* Multi-Agent Swarm Consensus Matrix Display */}
                    {(item.consensus || item.proposal?.consensusMatrix) && (
                      <div className="p-2 rounded-lg bg-black/60 border border-purple-500/30 space-y-1.5 font-mono text-[10px]">
                        <div className="flex items-center justify-between text-purple-300 font-bold border-b border-purple-500/20 pb-1">
                          <span className="flex items-center gap-1">
                            <Sparkles className="w-3 h-3 text-purple-400" />
                            <span>Multi-Agent Consensus Matrix (3/3 Ratified)</span>
                          </span>
                          <span className="text-emerald-400">99.9% Confidence</span>
                        </div>
                        <div className="space-y-1 text-[9.5px]">
                          {(item.consensus?.agents || item.proposal?.consensusMatrix.agents || []).map((ag) => (
                            <div key={ag.agentName} className="flex items-center justify-between text-slate-300 bg-white/5 p-1 rounded">
                              <span className="font-bold text-cyan-300">{ag.agentName}</span>
                              <span className="text-emerald-300 font-semibold">{ag.verdict} ({ag.confidenceScore}%)</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Direct One-Click Approval Gate */}
                    {item.proposal && (
                      <div className="p-2.5 rounded-lg bg-cyan-950/40 border border-cyan-500/40 space-y-2 font-mono text-[10px]">
                        <div className="flex items-center justify-between text-cyan-200 font-bold">
                          <span>{item.proposal.title}</span>
                          <span className="px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[9px]">
                            {item.proposal.isApproved ? 'RATIFIED' : 'PENDING SOVEREIGN SIGN'}
                          </span>
                        </div>
                        <div className="text-slate-300 text-[9.5px]">
                          {item.proposal.proposedChange}
                        </div>
                        {item.proposal.isApproved ? (
                          <div className="p-1.5 rounded bg-emerald-950/80 border border-emerald-500/40 text-emerald-300 font-bold flex items-center justify-center gap-1.5 shadow-[0_0_10px_rgba(16,185,129,0.3)]">
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                            <span>✅ ลงนามอนุมัติแล้ว (#EP-SOVEREIGN-01) • 6-Gate Adapter Applied</span>
                          </div>
                        ) : (
                          <button
                            type="button"
                            onClick={async () => {
                              playTone(680, 0.04);
                              if (item.proposal) {
                                await copilotAssistantService.approveProposal(item.proposal.proposalId);
                                playAuditChime();
                              }
                            }}
                            className="w-full py-1.5 px-2.5 rounded-lg bg-gradient-to-r from-amber-600 via-emerald-600 to-teal-600 hover:from-amber-500 hover:to-teal-500 text-white font-bold flex items-center justify-center gap-1.5 cursor-pointer shadow-[0_0_12px_rgba(16,185,129,0.35)] transition-all"
                          >
                            <Lock className="w-3.5 h-3.5" />
                            <span>[ 🔒 ลงนามอนุมัติ (#EP-SOVEREIGN-01) ]</span>
                          </button>
                        )}
                      </div>
                    )}
                  </div>
                ))}
                <div ref={chatEndRef} />
              </div>

              <button
                type="button"
                onClick={handleDownloadSnapshot}
                className="w-full py-2 px-3 rounded-lg bg-cyan-950/90 border border-cyan-500/50 text-cyan-200 hover:bg-cyan-900 font-sans font-bold text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer shadow-[0_0_15px_rgba(6,182,212,0.2)]"
              >
                <Download className="w-3.5 h-3.5" />
                <span>ดาวน์โหลด Signed Snapshot ทันที (FIPS 204 JSON)</span>
              </button>
            </div>

            {/* Live Reflex Logs Strip */}
            <div className="p-2.5 rounded-xl bg-slate-900/75 border border-slate-800 space-y-1.5">
              <div className="flex items-center justify-between text-[10px] text-cyan-300 font-bold">
                <span>Autonomous Reflex &amp; Self-Tuning Log Stream</span>
                <span className="text-emerald-400">SSoT Δ0.00%</span>
              </div>
              <div className="space-y-1">
                {copilotState.reflexLogs.slice(0, 4).map((log) => (
                  <div
                    key={log.id}
                    className="p-2 rounded-lg bg-slate-950/90 border border-slate-800/80 flex items-start justify-between gap-2 text-[10px]"
                  >
                    <span className="text-slate-300 font-sans leading-snug">{log.messageTh}</span>
                    <span className="px-1.5 py-0.5 rounded bg-cyan-500/15 text-cyan-300 border border-cyan-500/30 text-[9px] font-bold shrink-0">
                      {log.level}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </>
        )}

        {/* ============================================================ */}
        {/* TAB 1.5: COPILOT v7.0 NEURAL ORACLE (7-LAYER ARCHITECTURE)   */}
        {/* ============================================================ */}
        {activeTab === 'oracle7' && (
          <div className="space-y-2.5 font-sans">
            <div className="p-3 rounded-xl bg-gradient-to-r from-purple-950/60 via-slate-900 to-cyan-950/60 border border-purple-500/45 space-y-2">
              <div className="flex items-center justify-between gap-2">
                <div>
                  <span className="text-[10px] font-mono text-purple-300 font-bold uppercase tracking-wider block">
                    COPILOT SOVEREIGN AI v7.0 • 7-LAYER NEURAL ORACLE ENGINE
                  </span>
                  <h3 className="text-xs sm:text-sm font-black text-white mt-0.5">
                    สถาปัตยกรรมประสาทเทียมอธิปไตย 7 ชั้น (7-Layer Neural Oracle &amp; Court-Annex v2)
                  </h3>
                </div>
                <span className="px-2 py-0.5 rounded bg-emerald-500/20 border border-emerald-400/50 text-emerald-300 text-[9.5px] font-mono font-bold shrink-0">
                  7/7 LAYERS ONLINE
                </span>
              </div>
              <p className="text-[11px] text-slate-300 leading-relaxed">
                ยกระดับจาก v6.0 สู่ <strong className="text-purple-300">v7.0 Sovereign Neural Oracle</strong> ผสานการตรวจสอบลายมือชื่อควอนตัม{' '}
                <strong className="text-cyan-300 font-mono">ML-DSA-87</strong> และสำนวนศาล{' '}
                <strong className="text-amber-300 font-mono">COURT-ANNEX-v2 (แบบ จพ.๐๓ • 8/8 Vectors)</strong> เข้ากับท่อส่งนิติวิทยาศาสตร์ 16 ขั้นตอนแบบไร้รอยต่อ
              </p>
            </div>

            <div className="space-y-1.5">
              {V7_NEURAL_ORACLE_LAYERS.map((layer) => (
                <div
                  key={layer.layerId}
                  className="p-2.5 rounded-xl bg-slate-900/95 border border-slate-800 hover:border-purple-500/50 transition-all flex items-center justify-between gap-2"
                >
                  <div className="min-w-0 flex-1 space-y-0.5">
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <span className="px-1.5 py-0.5 rounded bg-purple-500/25 border border-purple-400/50 text-purple-200 font-mono text-[9.5px] font-bold">
                        {layer.layerId}
                      </span>
                      <span className="text-[11px] font-bold text-white">{layer.title}</span>
                      <span className="px-1.5 py-0.2 rounded bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 font-mono text-[9px]">
                        {layer.metric} • {layer.latency}
                      </span>
                    </div>
                    <p className="text-[10.5px] text-slate-300 leading-snug">{layer.descTh}</p>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      setActiveTab('dialogue');
                      void handleSend(layer.query);
                    }}
                    className="px-2.5 py-1 rounded-lg bg-purple-500/20 hover:bg-purple-500/30 border border-purple-400/40 text-purple-200 text-[10px] font-bold shrink-0 cursor-pointer transition-colors"
                  >
                    สั่งตรวจ {layer.layerId}
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ============================================================ */}
        {/* TAB 2: 16-STEP DIGITAL FORENSIC AUDIT REPORT & MATRIX        */}
        {/* ============================================================ */}
        {activeTab === 'forensic16' && (
          <div className="space-y-3 font-sans">
            {/* Report Header */}
            <div className="p-3 rounded-xl bg-gradient-to-r from-amber-950/50 via-slate-900 to-cyan-950/50 border border-amber-500/40 space-y-2">
              <div className="flex items-start justify-between gap-2">
                <div>
                  <span className="text-[10px] font-mono text-amber-300 font-bold uppercase tracking-wider block">
                    ISO/IEC 27037 • ETDA พ.ร.บ. ธุรกรรมทางอิเล็กทรอนิกส์ พ.ศ. ๒๕๔๔ • PDPA พ.ศ. ๒๕๖๒
                  </span>
                  <h3 className="text-xs sm:text-sm font-black text-white mt-0.5">
                    รายงานการตรวจสอบนิติวิทยาศาสตร์ดิจิทัลฉบับสมบูรณ์ 16 ขั้นตอน: ZYRQUEN Ω∞ Sovereign World Engine
                  </h3>
                </div>
                <button
                  type="button"
                  onClick={handleExport16StagePdf}
                  className="px-2.5 py-1.5 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 border border-amber-400/50 text-amber-200 text-[10px] font-bold flex items-center gap-1 shrink-0 cursor-pointer"
                >
                  <FileDown className="w-3.5 h-3.5" />
                  <span>Export PDF</span>
                </button>
              </div>

              <p className="text-[11px] text-slate-300 leading-relaxed">
                การยืนยันสภาวะแช่แข็งของระบบ ณ บล็อกปฐมกาล (#849202) คงสภาวะความเบี่ยงเบนของข้อมูลไว้ที่{' '}
                <strong className="text-emerald-300 font-mono">Δ0.00% Zero Drift</strong> บนสถานะความจริงเดี่ยว (SSoT)
                สร้างคุณสมบัติในการยับยั้งการปฏิเสธความรับผิดชอบ (Non-repudiation) ตาม พ.ร.บ. ว่าด้วยธุรกรรมทางอิเล็กทรอนิกส์ พ.ศ. ๒๕๔๔
              </p>
            </div>

            {/* Section 1: Sovereign Identity & System Verification Metadata */}
            <div className="p-3 rounded-xl bg-slate-900/95 border border-cyan-500/30 space-y-2">
              <div className="text-xs font-bold text-cyan-300 border-b border-slate-800 pb-1.5">
                1. ข้อมูลการตรวจสอบและตัวตนของระบบอธิปไตย (Sovereign Identity &amp; System Verification Metadata)
              </div>
              <div className="divide-y divide-slate-800/80 text-[11px]">
                {CANONICAL_FORENSIC_IDENTITY_METADATA.map((item) => (
                  <div
                    key={item.labelEn}
                    className="py-1.5 flex flex-col sm:flex-row sm:items-center justify-between gap-1"
                  >
                    <span className="text-slate-400 font-medium">
                      {item.labelTh}{' '}
                      <span className="text-[10px] text-slate-500 font-mono">({item.labelEn})</span>
                    </span>
                    <span
                      className={`font-mono font-bold text-right ${
                        item.highlight === 'amber'
                          ? 'text-amber-300'
                          : item.highlight === 'emerald'
                          ? 'text-emerald-300'
                          : 'text-cyan-200'
                      }`}
                    >
                      {item.verifiedValue}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Section 2: 16-Step Forensic Audit Pipeline Execution Matrix */}
            <div className="p-3 rounded-xl bg-slate-900/95 border border-emerald-500/35 space-y-2.5">
              <div className="flex items-center justify-between gap-2 border-b border-slate-800 pb-1.5">
                <div>
                  <div className="text-xs font-bold text-emerald-300">
                    2. ผลการตรวจสอบท่อส่งนิติวิทยาศาสตร์ดิจิทัล 16 ขั้นตอน (16-Step Forensic Audit Pipeline)
                  </div>
                  <div className="text-[10px] text-slate-400 font-mono">
                    Deterministic Alignment: 100% PASSED (16/16) • คลิกที่แต่ละด่านเพื่อดูข้อมูลเชิงลึก
                  </div>
                </div>
                <button
                  type="button"
                  onClick={handleAutoTuneAll16Stages}
                  disabled={isAutoTuningSweep}
                  className="px-2.5 py-1 rounded-lg bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-400/50 text-emerald-200 text-[10px] font-bold flex items-center gap-1 shrink-0 cursor-pointer"
                >
                  <RefreshCw className={`w-3 h-3 ${isAutoTuningSweep ? 'animate-spin' : ''}`} />
                  <span>Sweep 16/16</span>
                </button>
              </div>

              {/* Selected Stage Deep-Dive Box */}
              <div className="p-2.5 rounded-xl bg-slate-950 border border-cyan-500/40 space-y-1">
                <div className="flex items-center justify-between text-[10.5px] font-mono">
                  <span className="text-cyan-300 font-bold">
                    รายละเอียดเชิงลึก {selectedStage.stageId}: {selectedStage.title}
                  </span>
                  <span className="px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-[9px] font-bold">
                    {selectedStage.status} • {selectedStage.latencyMs}ms
                  </span>
                </div>
                <div className="text-[10px] text-amber-300 font-mono">
                  กลไกการเข้ารหัสและมาตรฐาน: {selectedStage.mechanism}
                </div>
                <p className="text-[11px] text-slate-300 leading-relaxed">{selectedStage.detailTh}</p>
              </div>

              {/* 16 Stages Table */}
              <div className="space-y-1 max-h-64 overflow-y-auto pr-1 custom-scrollbar font-mono">
                {CANONICAL_16_FORENSIC_STAGES.map((stg, idx) => {
                  const isSelected = selectedStage.stageId === stg.stageId;
                  const isLiveActive = copilotState.activeForensicStageIndex === idx;
                  return (
                    <div
                      key={stg.stageId}
                      onClick={() => {
                        playTone(680, 0.03);
                        setSelectedStage(stg);
                      }}
                      className={`p-2 rounded-lg border transition-all cursor-pointer flex items-center justify-between gap-2 text-[10px] ${
                        isSelected
                          ? 'bg-cyan-950/60 border-cyan-400/70 text-white'
                          : isLiveActive
                          ? 'bg-emerald-950/30 border-emerald-500/40 text-slate-200'
                          : 'bg-slate-950/90 border-slate-800/90 hover:border-slate-700 text-slate-300'
                      }`}
                    >
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-1.5">
                          <span className="px-1.5 py-0.2 rounded bg-cyan-500/20 text-cyan-300 font-bold shrink-0">
                            {stg.stageId}
                          </span>
                          <span className="font-bold text-white truncate">{stg.title}</span>
                        </div>
                        <div className="text-[9.5px] text-slate-400 truncate mt-0.5">
                          {stg.mechanism}
                        </div>
                      </div>
                      <span className="px-1.5 py-0.5 rounded bg-emerald-500/15 border border-emerald-500/35 text-emerald-300 text-[9px] font-bold shrink-0 tabular-nums">
                        {stg.status}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'autonomy' && (
          <div className="space-y-3">
            <CopilotAutonomyNodePanel
              onNavigateToView={(viewId) => {
                if (onNavigate) onNavigate(viewId as ViewType);
              }}
            />
          </div>
        )}

        {activeTab === 'files' && (
          <div className="p-3 rounded-xl bg-slate-900/95 border border-emerald-500/35 space-y-3">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <div className="flex items-center gap-2">
                <GitBranch className="w-4 h-4 text-emerald-400" />
                <div>
                  <div className="text-xs font-bold text-white">
                    ศูนย์ซิงค์ GitHub SSoT &amp; รายการไฟล์ทั้งหมด ({syncedFiles.length} Core Files)
                  </div>
                  <div className="text-[10px] text-slate-400">
                    Repo: {gitSyncState.remoteRepo} ({gitSyncState.remoteBranch}) • Block #{gitSyncState.localBlockHeight} • Parity {gitSyncState.merkleParityPercentage}%
                  </div>
                </div>
              </div>
              <button
                type="button"
                data-testid="btn-copilot-pull-all-files"
                onClick={handlePullAndSyncAllFiles}
                disabled={isSyncingAllFiles}
                className="px-3 py-1.5 rounded-lg bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-400/50 text-emerald-200 text-[10px] font-bold flex items-center gap-1.5 cursor-pointer"
              >
                <FolderSync className={`w-3 h-3 ${isSyncingAllFiles ? 'animate-spin' : ''}`} />
                <span>{isSyncingAllFiles ? 'Syncing...' : 'Sync GitHub Now'}</span>
              </button>
            </div>

            <div className="space-y-1.5">
              {syncedFiles.map((file) => (
                <div
                  key={file.path}
                  className="p-2.5 rounded-xl bg-slate-950/90 border border-slate-800 hover:border-cyan-500/40 transition-colors flex items-center justify-between gap-2"
                >
                  <div className="min-w-0 space-y-0.5">
                    <div className="flex items-center gap-1.5">
                      <Layers className="w-3 h-3 text-cyan-400 shrink-0" />
                      <span className="text-[11px] font-bold text-white truncate">{file.path}</span>
                      <span className="px-1.5 py-0.2 rounded bg-slate-800 text-cyan-300 text-[9px]">
                        {file.category}
                      </span>
                    </div>
                    <p className="text-[10px] text-slate-400 font-sans truncate">{file.descriptionTh}</p>
                  </div>
                  <div className="text-right shrink-0">
                    <span className="px-2 py-0.5 rounded bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-[9px] font-bold block">
                      ✓ {file.status}
                    </span>
                    <span className="text-[9px] text-slate-500 tabular-nums">
                      {file.sizeKb} • {file.shaShort}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Quick Action Matrix (Without Redundant Duplicate GitHub Pull Button) */}
        <div className="grid grid-cols-3 gap-1.5 text-[10.5px] font-sans pt-1">
          <button
            type="button"
            onClick={handleAutoTuneAll16Stages}
            className="p-2 rounded-xl bg-slate-900 border border-emerald-500/40 text-emerald-300 hover:bg-emerald-950/60 hover:border-emerald-400 font-bold truncate flex items-center justify-center gap-1 cursor-pointer transition-all"
          >
            <Zap className={`w-3 h-3 shrink-0 text-amber-300 ${isAutoTuningSweep ? 'animate-spin' : ''}`} />
            <span className="truncate">ปรับจูน 16 ขั้นตอน</span>
          </button>
          <button
            type="button"
            onClick={handleDownloadSnapshot}
            className="p-2 rounded-xl bg-slate-900 border border-cyan-500/40 text-cyan-300 hover:bg-cyan-950/60 hover:border-cyan-400 font-bold truncate flex items-center justify-center gap-1 cursor-pointer transition-all"
          >
            <Download className="w-3 h-3 shrink-0" />
            <span className="truncate">Signed Snapshot</span>
          </button>
          <button
            type="button"
            onClick={() => {
              setActiveTab('forensic16');
              void handleSend('ตรวจสอบรายงานนิติวิทยาศาสตร์ 16 ขั้นตอน และ PQC Dilithium-5');
            }}
            className="p-2 rounded-xl bg-slate-900 border border-purple-500/40 text-purple-300 hover:bg-purple-950/60 hover:border-purple-400 font-bold truncate flex items-center justify-center gap-1 cursor-pointer transition-all"
          >
            <ShieldCheck className="w-3 h-3 shrink-0" />
            <span className="truncate">รายงาน 16 ขั้นตอน</span>
          </button>
        </div>
      </div>

      {/* Bottom Command Prompt with v7.0 1-Click Smart Prompt Chips */}
      <div className="p-2.5 bg-slate-900 border-t border-slate-800 shrink-0 space-y-1.5">
        <div className="flex items-center gap-1 overflow-x-auto no-scrollbar py-0.5 font-sans text-[10px]">
          <span className="text-slate-400 font-mono text-[9.5px] shrink-0">v7 Prompts:</span>
          {[
            { label: '⚡ ปรับจูน 16 ขั้นตอน', query: 'ปรับจูนอัตโนมัติ 16 ขั้นตอน' },
            { label: '🛡️ ตรวจ 10/10 HSM', query: 'ตรวจสอบ PQC Dilithium-5 และ 10/10 REAL_HSM Quorum' },
            { label: '⚖️ สำนวนศาล จพ.๐๓', query: 'ตรวจสอบรายงานนิติวิทยาศาสตร์ 16 ขั้นตอน และ PQC Dilithium-5' },
            { label: '🌐 โหมด Sphere 3D', query: 'สลับโหมด Sphere' },
            { label: '📜 กฎเหล็ก SSoT Δ0', query: 'ขอทราบกฎเหล็ก coding rules ของระบบ' },
          ].map((chip) => (
            <button
              key={chip.label}
              type="button"
              onClick={() => {
                setActiveTab('dialogue');
                void handleSend(chip.query);
              }}
              className="px-2 py-0.5 rounded-md bg-slate-950 hover:bg-cyan-950/70 border border-slate-700 hover:border-cyan-500/50 text-cyan-200 shrink-0 cursor-pointer transition-colors"
            >
              {chip.label}
            </button>
          ))}
        </div>
        <div className="flex items-center gap-1.5 bg-slate-950 rounded-xl border border-slate-800 px-3 py-1.5 focus-within:border-cyan-500/60 transition-colors">
          <input
            type="text"
            value={inputMsg}
            onChange={(e) => setInputMsg(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') {
                void handleSend();
              }
            }}
            placeholder="สั่งการ Copilot เช่น ปรับจูนอัตโนมัติ 16 ขั้นตอน, ตรวจ STG-01..16, สลับโหมด Sphere..."
            className="w-full bg-transparent text-xs text-white placeholder-slate-500 focus:outline-none"
          />
          <button
            type="button"
            onClick={() => void handleSend()}
            className="px-3 py-1.5 rounded-lg bg-cyan-500/25 text-cyan-200 border border-cyan-500/50 hover:bg-cyan-500/35 font-bold text-xs flex items-center gap-1 shrink-0 transition-colors cursor-pointer"
          >
            <span>สั่งการ</span>
            <Send className="w-3 h-3" />
          </button>
        </div>
      </div>
    </aside>
  );
};
