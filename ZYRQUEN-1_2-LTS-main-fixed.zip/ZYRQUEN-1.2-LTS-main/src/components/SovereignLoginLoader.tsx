import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { playTone, playAuditChime } from './AudioSynthesizer';
import { Fingerprint, Key, ShieldCheck, CheckCircle2, AlertTriangle, Cpu } from 'lucide-react';
import { webAuthnService, WebAuthnAuthenticationResult } from '../services/webAuthnService';

interface SovereignLoginLoaderProps {
  isOpen: boolean;
  onComplete: () => void;
  onCancel?: () => void;
  mode?: 'login' | 'register' | 'switch_tenant';
  onModeChange?: (newMode: 'login' | 'register' | 'switch_tenant') => void;
}

const HSM_SLOTS = [
  { id: 1, name: 'HSM-01', algo: 'ML-KEM-1024', status: 'LOCKED', color: '#06B6D4' },
  { id: 2, name: 'HSM-02', algo: 'ML-DSA-87', status: 'LOCKED', color: '#06B6D4' },
  { id: 3, name: 'HSM-03', algo: 'SLH-DSA', status: 'LOCKED', color: '#06B6D4' },
  { id: 4, name: 'HSM-04', algo: 'FIPS 140-3', status: 'LOCKED', color: '#D4AF37' },
  { id: 5, name: 'HSM-05', algo: 'ETDA Sec 9', status: 'LOCKED', color: '#D4AF37' },
  { id: 6, name: 'HSM-06', algo: 'PDPA Sec 26', status: 'LOCKED', color: '#D4AF37' },
  { id: 7, name: 'HSM-07', algo: 'CRYO 14.98mK', status: 'LOCKED', color: '#10B981' },
  { id: 8, name: 'HSM-08', algo: 'DAG-6-STAGE', status: 'LOCKED', color: '#10B981' },
  { id: 9, name: 'HSM-09', algo: 'Ω600_1000', status: 'LOCKED', color: '#8B5CF6' },
  { id: 10, name: 'HSM-10', algo: 'OMEGA-1 HQ', status: 'LOCKED', color: '#8B5CF6' },
];

const SOVEREIGN_PHASES = [
  { at: 10, title: 'Quantum Warp Stream Synchronizing...', tone: 520 },
  { at: 25, title: 'Dilithium-5 / ML-KEM-1024 Lattice Handshake Initialized', tone: 580 },
  { at: 45, title: 'Genesis Merkle Root #849202 Bound (14,902 Seals Verified)', tone: 640 },
  { at: 65, title: 'FIPS 140-3 Level 4 HSM 10/10 Quorum Attestation Signed', tone: 720 },
  { at: 85, title: 'Thai Legal Safe Harbor (ETDA & PDPA) Enclave Armed', tone: 800 },
  { at: 95, title: 'Ω600_1000 Sovereign Tenant Lattice Stabilized (Δ0.00% Drift)', tone: 880 },
  { at: 100, title: 'OMEGA INFINITY LOCKED — RUNTIME VERIFIED 100% GREEN', tone: 960 },
];

export const SovereignLoginLoader: React.FC<SovereignLoginLoaderProps> = ({
  isOpen,
  onComplete,
  onCancel,
  mode: initialMode = 'login',
  onModeChange,
}) => {
  const [activeMode, setActiveMode] = useState<'login' | 'register' | 'switch_tenant'>(initialMode);
  const [progress, setProgress] = useState<number>(0);

  useEffect(() => {
    setActiveMode(initialMode);
  }, [initialMode]);

  const toggleLoginRegister = () => {
    const nextMode = activeMode === 'login' ? 'register' : 'login';
    playTone(550, 0.05);
    setActiveMode(nextMode);
    if (onModeChange) {
      onModeChange(nextMode);
    }
  };
  const [phaseText, setPhaseText] = useState<string>('Initializing Sovereign Warp Runtime...');
  const [signedHsmCount, setSignedHsmCount] = useState<number>(0);
  const [currentEntropy, setCurrentEntropy] = useState<number>(0.0);
  const [warpSpeedQops, setWarpSpeedQops] = useState<number>(12480);
  const [isWarpFlash, setIsWarpFlash] = useState<boolean>(false);
  
  // Biometric challenge state
  const [showBiometricChallenge, setShowBiometricChallenge] = useState<boolean>(false);
  const [biometricVerified, setBiometricVerified] = useState<boolean>(false);
  const [isVerifyingWebAuthn, setIsVerifyingWebAuthn] = useState<boolean>(false);
  const [webAuthnFeedback, setWebAuthnFeedback] = useState<string>('');
  const [webAuthnResult, setWebAuthnResult] = useState<WebAuthnAuthenticationResult | null>(null);

  useEffect(() => {
    if (!isOpen) {
      setProgress(0);
      setSignedHsmCount(0);
      setIsWarpFlash(false);
      setShowBiometricChallenge(false);
      setBiometricVerified(false);
      setIsVerifyingWebAuthn(false);
      setWebAuthnFeedback('');
      setWebAuthnResult(null);
      return;
    }

    playTone(440, 0.1);

    const interval = setInterval(() => {
      setProgress((prev) => {
        // Biometric pause
        if (prev >= 45 && prev < 50 && !biometricVerified && !showBiometricChallenge) {
          setShowBiometricChallenge(true);
          return prev;
        }
        
        if (showBiometricChallenge && !biometricVerified) {
          return prev;
        }

        if (prev >= 100) {
          clearInterval(interval);
          return 100;
        }

        const next = Math.min(100, prev + 3);
        
        // Update Signed HSM Count
        const currentSlot = Math.min(10, Math.floor((next / 100) * 10));
        setSignedHsmCount(currentSlot);

        // Update Phase Text & Audio Pitch
        const matchedPhase = [...SOVEREIGN_PHASES].reverse().find((p) => next >= p.at);
        if (matchedPhase) {
          setPhaseText(matchedPhase.title);
        }

        // Live Warp Metrics Jitter
        setWarpSpeedQops(12480 + Math.floor(Math.sin(next) * 520));

        if (next % 12 === 0) {
          playTone(480 + next * 4, 0.02);
        }

        if (next === 100) {
          playAuditChime();
          setIsWarpFlash(true);
          setTimeout(() => {
            onComplete();
          }, 900);
        }

        return next;
      });
    }, 70);

    return () => clearInterval(interval);
  }, [isOpen, showBiometricChallenge, biometricVerified, onComplete]);

  const handleWebAuthnBiometric = async (forceSimulated = false) => {
    setIsVerifyingWebAuthn(true);
    setWebAuthnFeedback('Prompting WebAuthn API for biometric sensor touch / security key...');
    playTone(600, 0.05);

    try {
      const result = await webAuthnService.authenticateWithPasskey({
        customChallenge: 'SOVEREIGN_QUANTUM_WARP_INGRESS_CHALLENGE',
        forceSimulated,
      });

      if (result.success) {
        setWebAuthnResult(result);
        setWebAuthnFeedback('WebAuthn assertion ratified. Biometric signature valid (ETDA Sec 9/26).');
        playAuditChime();
        setTimeout(() => {
          setBiometricVerified(true);
          setShowBiometricChallenge(false);
          setIsVerifyingWebAuthn(false);
        }, 1200);
      } else {
        setWebAuthnFeedback(result.error || 'Biometric verification failed.');
        setIsVerifyingWebAuthn(false);
      }
    } catch (err: any) {
      setWebAuthnFeedback(err?.message || 'Biometric ceremony cancelled.');
      setIsVerifyingWebAuthn(false);
    }
  };

  const handleBiometricAccept = () => {
    handleWebAuthnBiometric(true);
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0, transition: { duration: 0.75, ease: [0.16, 1, 0.3, 1] } }}
        className="fixed inset-0 z-50 flex items-center justify-center bg-[#070a12] p-4 font-mono select-none overflow-hidden"
      >
        {/* Holographic Warp Stream Particle & Ingress Field */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute inset-0 bg-[#070a12] opacity-95" />

          {/* Relativistic Warp Stream Light Streaks (Warp Ingress Corridor) */}
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            {[0, 30, 60, 90, 120, 150, 180, 210, 240, 270, 300, 330].map((deg) => (
              <motion.div
                key={deg}
                initial={{ opacity: 0, scaleY: 0.2 }}
                animate={{
                  opacity: isWarpFlash ? [0.4, 0.9, 0] : [0.15, 0.45, 0.2],
                  scaleY: isWarpFlash ? [1, 2.5, 4] : [0.8, 1.25, 0.9],
                }}
                transition={{
                  duration: isWarpFlash ? 0.8 : 2.4,
                  repeat: isWarpFlash ? 0 : Infinity,
                  repeatType: 'reverse',
                  delay: (deg / 360) * 0.4,
                  ease: 'easeInOut',
                }}
                style={{ transform: `rotate(${deg}deg)` }}
                className="absolute w-[2px] h-[1200px] bg-gradient-to-t from-transparent via-cyan-400/30 to-transparent pointer-events-none"
              />
            ))}
          </div>
          
          {/* Subtle Radial Warp Tunnel Rings with Ingress Acceleration */}
          <motion.div
            initial={{ scale: 0.25, opacity: 0, rotate: -20 }}
            animate={{
              scale: isWarpFlash ? [1, 2.2, 3.2] : [0.4, 1.1, 1],
              opacity: isWarpFlash ? [0.4, 0.8, 0] : [0, 0.45, 0.25],
              rotate: 0,
            }}
            transition={{ duration: isWarpFlash ? 0.85 : 1.2, ease: [0.16, 1, 0.3, 1] }}
            className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[900px] h-[900px] rounded-full border border-cyan-500/25 pointer-events-none"
          />
          <motion.div
            initial={{ scale: 0.15, opacity: 0, rotate: 20 }}
            animate={{
              scale: isWarpFlash ? [1, 2.4, 3.6] : [0.2, 1.2, 1],
              opacity: isWarpFlash ? [0.5, 0.9, 0] : [0, 0.5, 0.3],
              rotate: 0,
            }}
            transition={{ duration: isWarpFlash ? 0.85 : 1.4, delay: 0.08, ease: [0.16, 1, 0.3, 1] }}
            className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[650px] h-[650px] rounded-full border border-[#D4AF37]/30 pointer-events-none"
          />
          <motion.div
            initial={{ scale: 0.08, opacity: 0 }}
            animate={{
              scale: isWarpFlash ? [1, 2.8, 4.2] : [0.1, 1.3, 1],
              opacity: isWarpFlash ? [0.6, 1, 0] : [0, 0.6, 0.35],
            }}
            transition={{ duration: isWarpFlash ? 0.85 : 1.6, delay: 0.16, ease: [0.16, 1, 0.3, 1] }}
            className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[420px] h-[420px] rounded-full border border-emerald-500/25 pointer-events-none"
          />

          {/* Warp Ingress Radial Stream Gradient */}
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_transparent_15%,_rgba(6,182,212,0.08)_55%,_rgba(7,10,18,0.96)_88%)] pointer-events-none" />

          {/* Hyper-Warp Flash Burst (When transitioning to dashboard) */}
          {isWarpFlash && (
            <motion.div
              initial={{ opacity: 0, scale: 0.6 }}
              animate={{ opacity: [0, 1, 0], scale: [0.6, 2.4, 4.2] }}
              transition={{ duration: 0.9, ease: [0.16, 1, 0.3, 1] }}
              className="absolute inset-0 z-30 flex items-center justify-center pointer-events-none"
            >
              <div className="w-[600px] h-[600px] rounded-full bg-gradient-to-r from-cyan-400/50 via-white/80 to-[#D4AF37]/50 blur-3xl" />
            </motion.div>
          )}
        </div>

        {/* Central Quantum Warp Login Enclave with Subtle Warp Ingress Entrance */}
        <motion.div
          initial={{ opacity: 0, scale: 0.74, y: 36, rotateX: 6, filter: 'blur(12px) brightness(1.6)' }}
          animate={{
            opacity: 1,
            scale: isWarpFlash ? 1.08 : 1,
            y: 0,
            rotateX: 0,
            filter: isWarpFlash ? 'brightness(1.4) blur(0.5px)' : 'blur(0px) brightness(1)',
          }}
          exit={{
            opacity: 0,
            scale: 1.28,
            y: -24,
            filter: 'blur(16px) brightness(2.2)',
            transition: { duration: 0.75, ease: [0.16, 1, 0.3, 1] },
          }}
          transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
          className="relative z-10 w-full max-w-2xl p-8 rounded-3xl bg-[#0a0f1e]/95 backdrop-blur-xl border-2 border-[#D4AF37] shadow-[0_0_50px_rgba(212,175,55,0.25)] space-y-6 text-zinc-100"
        >
          {/* Subtle Warp Ingress Indicator Kicker */}
          <div className="flex items-center justify-between text-[10px] text-cyan-400/90 font-mono tracking-wider border-b border-cyan-500/20 pb-2">
            <span className="flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-ping" />
              <span>WARP INGRESS VECTOR // STABLE ORBIT ENTRY</span>
            </span>
            <span className="text-zinc-400">
              SPEED: <span className="text-cyan-300 font-bold">{warpSpeedQops.toLocaleString()}</span> QOPS/S · LATENCY: &lt;1.2MS
            </span>
          </div>
          {/* Sovereign Warp Header */}
          <div className="flex items-center justify-between border-b border-zinc-800 pb-4">
            <div className="flex items-center gap-3">
              <span className="text-3xl">🏛️</span>
              <div>
                <div className="flex items-center gap-2">
                  <h1 className="text-lg font-bold tracking-widest text-[#D4AF37] uppercase">
                    ZYRQUEN Ω∞ SOVEREIGN RUNTIME
                  </h1>
                  <span className="px-2 py-0.5 rounded bg-cyan-950 border-cyan-500/50 text-cyan-300 text-[10px] font-bold">
                    FROZEN v1.2.1 LTS
                  </span>
                </div>
                <p className="text-xs text-zinc-400">
                  {activeMode === 'login'
                    ? 'Sovereign Multi-Pass Quantum Login & Warp Ingress'
                    : activeMode === 'register'
                    ? 'Registering Cryptographic Identity (#EP-SOVEREIGN-01)'
                    : 'Switching Sovereign Tenant Partition (Ω600_1000)'}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              {/* Switch to Register / Switch to Login toggle button */}
              <button
                type="button"
                onClick={toggleLoginRegister}
                className="px-3 py-1.5 rounded-xl border border-cyan-500/40 bg-cyan-950/60 hover:bg-cyan-900/80 text-cyan-300 hover:text-white text-xs font-semibold transition-all cursor-pointer shadow-[0_0_15px_rgba(6,182,212,0.2)]"
              >
                {activeMode === 'login' ? 'Switch to Register' : 'Switch to Login'}
              </button>

              <div className="text-right">
                <span className="text-xs text-zinc-400">AUTHORITY</span>
                <div className="text-xs font-bold text-emerald-400">OMEGA-1 SUPREME</div>
              </div>
            </div>
          </div>

          {/* Biometric Challenge Overlay */}
          <AnimatePresence>
            {showBiometricChallenge && !biometricVerified && (
              <motion.div 
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 1.05 }}
                className="absolute inset-0 z-20 flex flex-col items-center justify-center bg-[#0a0f1e]/98 backdrop-blur-2xl border-2 border-cyan-500/50 rounded-3xl p-8"
              >
                <div className="w-20 h-20 rounded-full border-4 border-cyan-500/30 border-t-cyan-400 animate-spin mb-4 flex items-center justify-center relative">
                  <div className="absolute inset-2 border-2 border-emerald-400/20 border-b-emerald-400 rounded-full animate-spin-reverse" />
                  <Fingerprint className="w-9 h-9 text-cyan-400 animate-pulse relative z-10" />
                </div>

                <h2 className="text-cyan-400 font-bold text-lg tracking-widest mb-1 uppercase text-center flex items-center gap-2">
                  <span>WebAuthn Biometric Presence Challenge</span>
                </h2>
                <div className="text-[11px] text-emerald-400 font-semibold mb-3">
                  FIPS 140-3 L4 • ETDA B.E. 2544 Sec 9/26 Non-Repudiation
                </div>

                <p className="text-zinc-400 text-xs mb-4 text-center max-w-md">
                  A cryptographic identity ceremony is required. Touch your device biometric scanner (Touch ID / Face ID / Windows Hello) or authenticate via FIPS 140-3 hardware security key.
                </p>

                {webAuthnFeedback && (
                  <div className="w-full max-w-md p-2.5 mb-4 rounded-xl bg-cyan-950/50 border-cyan-500/40 text-xs text-cyan-200 text-center font-mono">
                    {webAuthnFeedback}
                  </div>
                )}

                {webAuthnResult && (
                  <div className="w-full max-w-md p-2.5 mb-4 rounded-xl bg-emerald-950/60 border-emerald-500/50 text-[11px] text-emerald-300 font-mono space-y-1">
                    <div className="flex justify-between font-bold">
                      <span>✓ WebAuthn Verified</span>
                      <span>{webAuthnResult.fipsLevel}</span>
                    </div>
                    <div className="text-[10px] text-zinc-400 truncate">
                      Sig: {webAuthnResult.signatureHex}
                    </div>
                  </div>
                )}

                <div className="flex flex-col sm:flex-row items-center gap-3 w-full max-w-md">
                  <button
                    onClick={() => handleWebAuthnBiometric(false)}
                    disabled={isVerifyingWebAuthn}
                    className="flex-1 w-full py-3 px-4 bg-gradient-to-r from-cyan-500 to-emerald-500 hover:from-cyan-400 hover:to-emerald-400 text-black font-bold text-xs tracking-wider uppercase rounded-xl transition-all shadow-[0_0_20px_rgba(6,182,212,0.3)] active:scale-95 flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                  >
                    <Fingerprint className="w-4 h-4" />
                    <span>{isVerifyingWebAuthn ? 'Awaiting Sensor...' : 'Touch Biometric Sensor'}</span>
                  </button>

                  <button
                    onClick={handleBiometricAccept}
                    disabled={isVerifyingWebAuthn}
                    className="py-3 px-4 bg-white/5 hover:bg-white/10 border-white/20 text-zinc-300 hover:text-white font-semibold text-xs tracking-wider uppercase rounded-xl transition-all active:scale-95 flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <Cpu className="w-4 h-4 text-[#D4AF37]" />
                    <span>Enclave Fallback</span>
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Warp Stream Hologram Progress Bar */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs">
              <div className="flex items-center gap-2">
                <span className="text-cyan-400 font-bold">QUANTUM WARP STREAM:</span>
                <span className="text-zinc-400">{warpSpeedQops} qOps/s</span>
              </div>
              <span className="text-[#D4AF37] font-bold text-sm tracking-wider">
                {progress}% {progress === 100 ? '✅ LOCKED' : '⚡ STREAMING'}
              </span>
            </div>

            {/* Custom Solid Progress Track */}
            <div className="w-full h-5 bg-[#070a12] border-cyan-500/40 rounded-full p-0.5 overflow-hidden">
              <motion.div
                className="h-full bg-cyan-400 rounded-full transition-all duration-100 relative"
                style={{ width: `${progress}%` }}
              >
                <div className="absolute top-0 right-0 bottom-0 w-4 bg-white opacity-80 animate-pulse rounded-r-full" />
              </motion.div>
            </div>
          </div>

          {/* Custodian HSM 10/10 Signatures Slots Grid */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs text-zinc-400">
              <span className="flex items-center gap-1.5">
                <span>🧊</span>
                <span className="font-bold text-zinc-200">REAL_HSM 10/10 QUORUM SEALS:</span>
              </span>
              <span className="text-emerald-400 font-bold">
                {signedHsmCount}/10 ATTESTED (FIPS 140-3 L4)
              </span>
            </div>

            <div className="grid grid-cols-5 gap-2">
              {HSM_SLOTS.map((slot) => {
                const isSigned = signedHsmCount >= slot.id;
                return (
                  <div
                    key={slot.id}
                    className={`p-2 rounded-xl border text-center transition-all duration-200 ${
                      isSigned
                        ? 'bg-[#070a12] border-emerald-500 text-emerald-300 shadow-md'
                        : 'bg-[#070a12] border-zinc-800 text-zinc-600'
                    }`}
                  >
                    <div className="text-[10px] font-bold">{slot.name}</div>
                    <div className="text-[8px] truncate">{slot.algo}</div>
                    <div className="mt-1 text-[9px] font-bold">
                      {isSigned ? '✅ SIGNED' : '⏳ QUEUED'}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* SSoT Drift & Genesis Merkle Indicators */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
            <div className="p-2.5 rounded-xl bg-[#070a12] border-zinc-800">
              <div className="text-[10px] text-zinc-400">ENTROPY DRIFT</div>
              <div className="text-emerald-400 font-bold">Δ0.00% ZERO DRIFT</div>
            </div>
            <div className="p-2.5 rounded-xl bg-[#070a12] border-zinc-800">
              <div className="text-[10px] text-zinc-400">MERKLE BLOCK</div>
              <div className="text-cyan-300 font-bold">#849202 (14.9K)</div>
            </div>
            <div className="p-2.5 rounded-xl bg-[#070a12] border-zinc-800">
              <div className="text-[10px] text-zinc-400">TENANT BOUNDARY</div>
              <div className="text-[#D4AF37] font-bold">Ω600_1000</div>
            </div>
            <div className="p-2.5 rounded-xl bg-[#070a12] border-zinc-800">
              <div className="text-[10px] text-zinc-400">LEGAL HARBOR</div>
              <div className="text-cyan-400 font-bold">ETDA & PDPA</div>
            </div>
          </div>

          {/* Live Status Message Log */}
          <div className="p-3 rounded-xl bg-[#070a12] border-cyan-500/30 text-center">
            <p className="text-xs text-cyan-300 font-mono tracking-wide font-bold">
              {progress < 100 ? (
                <>⚡ {phaseText} ({progress}%)</>
              ) : (
                <span className="text-emerald-400">👑 OMEGA INFINITY LOCKED — RUNTIME VERIFIED 100% GREEN</span>
              )}
            </p>
          </div>

          {/* Actions */}
          {onCancel && progress < 100 && (
            <div className="flex justify-end pt-2">
              <button
                onClick={() => {
                  playTone(400, 0.05);
                  onCancel();
                }}
                className="px-4 py-1.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 border-zinc-700 text-zinc-400 hover:text-white text-xs cursor-pointer"
              >
                ABORT INGRESS
              </button>
            </div>
          )}
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
};
