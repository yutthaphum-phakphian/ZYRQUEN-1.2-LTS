import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ViewType } from '../types';
import { SYSTEM_METADATA } from '../data/canonicalData';
import {
  LayoutDashboard,
  Cpu,
  Share2,
  Lock,
  FileCheck2,
  Activity,
  Workflow,
  Orbit,
  Archive,
  Terminal,
  ShieldCheck,
  ShieldAlert,
  Settings,
  Crown,
  Volume2,
  VolumeX,
  Award,
  Sparkles,
  Scale,
  Search,
  Keyboard,
  Users,
  TrendingUp,
  Bell,
  Radio,
  Snowflake,
  LayoutGrid,
  Grid3X3,
  Boxes,
  Eye,
  Fingerprint,
  Camera,
  Menu,
  PanelLeftClose,
  PanelLeft,
  ChevronLeft,
  ChevronRight,
  History,
  Landmark,
  Wallet,
  Github,
  Smartphone,
} from 'lucide-react';
import { playTone, getHarmonicCarrierSnapshot } from './AudioSynthesizer';
import { PWAInstallButton } from './PWAInstallButton';
import { GitHubSyncWarningNav } from './navigation/GitHubSyncWarningNav';
import { HsmQuorumAlertBanner } from './navigation/HsmQuorumAlertBanner';
import { hsmClusterService, HsmClusterState } from '../services/hsmClusterService';
import { CopilotAssistantDrawer } from './copilot/CopilotAssistantDrawer';
import { ThemeSwitcher } from './ThemeSwitcher';
import { ZyrquenIcon } from './ZyrquenIcon';
import { TopNavGlobalSearchBar } from './navigation/TopNavGlobalSearchBar';
import { sessionService, AuthenticatedSession } from '../services/sessionService';

interface NavigationProps {
  currentView: ViewType;
  onSelectView: (view: ViewType) => void;
  onOpenCertificate: () => void;
  onOpenForensicDossier?: () => void;
  onOpenChecklist?: () => void;
  onOpenLegalSearch: () => void;
  onOpenCommandSearch?: () => void;
  onOpenShortcuts: () => void;
  onOpenGitHubPwa?: () => void;
  onOpenEventsSidebar?: () => void;
  eventsCount?: number;
  onCaptureSnapshot?: () => void;
  isAudioActive: boolean;
  onToggleAudio: () => void;
  isSystemActivityFrozen?: boolean;
  onToggleFreezeSystemActivity?: () => void;
  isForensicAuditMode?: boolean;
  onToggleForensicAuditMode?: () => void;
  sealCount?: number;
  isSnapshotIncrementing?: boolean;
  isSidebarOpen?: boolean;
  onToggleSidebar?: () => void;
  onTriggerLoginLoader?: (mode?: 'login' | 'register' | 'switch_tenant') => void;
  onOpenWebAuthn?: () => void;
  isCopilotOpen?: boolean;
  onToggleCopilot?: () => void;
  onOpenUpgradeCycle?: () => void;
}

interface NavItem {
  id: ViewType;
  labelEn: string;
  labelTh: string;
  primaryTh?: boolean;
  icon: React.FC<{ className?: string }>;
  dotColor: string;
  badge?: string;
  shortcut?: string;
}

export const NAVIGATION_ITEMS: NavItem[] = [
  { id: 'dashboard', labelEn: 'Dashboard', labelTh: 'ศูนย์บัญชาการ', icon: LayoutDashboard, dotColor: '#06B6D4', badge: 'HQ', shortcut: '1' },
  { id: 'treasury-variance', labelEn: 'Treasury & SAP Audit', labelTh: 'การกระทบยอดคลัง & SAP ERP', icon: Landmark, dotColor: '#10B981', badge: '฿0.00 SSoT', shortcut: 'T' },
  { id: 'sovereign', labelEn: 'Autonomous Self-Tuning Engine', labelTh: 'ศูนย์ควบคุมอัตโนมัติ Phase 11', icon: ShieldAlert, dotColor: '#06B6D4', badge: 'PHASE 11', shortcut: 'V' },
  { id: 'ai-workspace', labelEn: 'AI Workspace', labelTh: 'พื้นที่ทำงาน AI & แซนด์บ็อกซ์', icon: Sparkles, dotColor: '#06B6D4', badge: 'AI BOUNDARY', shortcut: 'M' },
  { id: 'briefing', labelEn: 'Executive & Court', labelTh: 'สรุปผู้บริหาร & ศาล', icon: Landmark, dotColor: '#D4AF37', badge: 'EXECUTIVE', shortcut: 'E' },
  { id: 'sovereign-wallet', labelEn: 'Sovereign Wallet', labelTh: 'กระเป๋าอธิปไตย & คีย์ QR', icon: Wallet, dotColor: '#D4AF37', badge: 'WEBAUTHN', shortcut: 'Q' },
  { id: 'fusion', labelEn: 'Fusion Console', labelTh: 'รวมศูนย์นิติวิทยาศาสตร์', icon: Activity, dotColor: '#D946EF', badge: 'FUSION', shortcut: 'F' },
  { id: 'playback', labelEn: '12-Stage Replay', labelTh: 'จำลองสืบย้อน', icon: ShieldCheck, dotColor: '#F59E0B', badge: 'TRACE', shortcut: 'P' },
  { id: 'chambers', labelEn: '18 Chambers', labelTh: '18 ห้องอธิปไตย SSoT', icon: LayoutGrid, dotColor: '#6366F1', badge: '18 SSoT', shortcut: 'K' },
  { id: 'civilization', labelEn: 'Civilization', labelTh: 'เครื่องยนต์อารยธรรม', icon: Crown, dotColor: '#D4AF37', badge: 'WARP Ω∞', shortcut: 'W' },
  { id: 'studio', labelEn: 'Studio 3D', labelTh: 'สตูดิโอ 3D โฮโลแกรม', icon: Boxes, dotColor: '#06B6D4', badge: '3D LATTICE', shortcut: 'S' },
  { id: 'unified', labelEn: 'Multiverse Panel', labelTh: 'แผงควบคุมรวมมิติ', icon: LayoutGrid, dotColor: '#38BDF8', badge: 'TRI-VIEW', shortcut: 'U' },
  { id: 'heatmap', labelEn: '14.9K Seals Heatmap', labelTh: 'แผนผังสุขภาพ 14,902 ตรา', icon: Grid3X3, dotColor: '#10B981', badge: '14.9K', shortcut: 'H' },
  { id: 'compliance-coverage', labelEn: 'Compliance Coverage', labelTh: 'แผนผังความครอบคลุม D3', icon: TrendingUp, dotColor: '#06B6D4', badge: 'D3 COV', shortcut: 'G' },
  { id: 'council', labelEn: 'Council 10/10', labelTh: 'สภาผู้พิทักษ์', icon: Crown, dotColor: '#F59E0B', badge: '10/10', shortcut: 'C' },
  { id: 'production', labelEn: 'Readiness', labelTh: 'ความพร้อมผลิต', icon: ShieldCheck, dotColor: '#10B981', badge: 'PH-20', shortcut: 'R' },
  { id: 'quantum', labelEn: 'Quantum', labelTh: 'ควอนตัมเน็กซัส', icon: Cpu, dotColor: '#8B5CF6', badge: '768-Q', shortcut: '2' },
  { id: 'nexus', labelEn: 'Nexus', labelTh: 'เครือข่ายข้อมูล', icon: Share2, dotColor: '#3B82F6', shortcut: '3' },
  { id: 'vault', labelEn: 'Vault', labelTh: 'คลังรหัสผ่าน', icon: Lock, dotColor: '#F59E0B', badge: 'OMEGA', shortcut: '4' },
  { id: 'ledger', labelEn: 'Ledger', labelTh: 'สมุดบัญชีหลักฐาน', icon: FileCheck2, dotColor: '#10B981', badge: '14.9K', shortcut: '5' },
  { id: 'audithistory', labelEn: 'Audit History', labelTh: 'ประวัติสแนปช็อต', icon: History, dotColor: '#10B981', badge: 'SNAPSHOTS', shortcut: 'J' },
  { id: 'pulse', labelEn: 'Pulse', labelTh: 'โทรมาตรเรียลไทม์', icon: Activity, dotColor: '#06B6D4', shortcut: '6' },
  { id: 'forge', labelEn: 'Forge', labelTh: 'โรงหลอมอัตโนมัติ', icon: Workflow, dotColor: '#F59E0B', shortcut: '7' },
  { id: 'matrix', labelEn: 'Matrix', labelTh: 'มัลติเวิร์สจำลอง', icon: Orbit, dotColor: '#8B5CF6', shortcut: '8' },
  { id: 'archive', labelEn: 'Archive', labelTh: 'คลังแมนิเฟสต์ 17', icon: Archive, dotColor: '#3B82F6', badge: '17 MOD', shortcut: '9' },
  { id: 'console', labelEn: 'Console', labelTh: 'เทอร์มินัล CLI', icon: Terminal, dotColor: '#10B981', badge: 'CLI', shortcut: '0' },
  { id: 'security', labelEn: 'Security', labelTh: 'โล่ซีโร่ทรัสต์', icon: ShieldCheck, dotColor: '#10B981', badge: 'ZERO', shortcut: '-' },
  { id: 'securitypipeline', labelEn: 'Security Pipeline', labelTh: 'ท่อส่งความปลอดภัย 3 ด่าน', icon: ShieldAlert, dotColor: '#06B6D4', badge: 'HOLO FLOW', shortcut: 'X' },
  { id: 'legal', labelEn: 'Legal & PDPA', labelTh: 'กฎหมายอธิปไตย', icon: Scale, dotColor: '#3B82F6', badge: 'PDPA', shortcut: 'L' },
  { id: 'canonical', labelEn: 'Canonical Integrity', labelTh: 'ความสมบูรณ์แคนอนิคัล', icon: ShieldCheck, dotColor: '#10B981', badge: 'STABLE LOCK', shortcut: 'I' },
  { id: 'admin', labelEn: 'Admin RBAC', labelTh: 'จัดการสิทธิ์ผู้ใช้', icon: Users, dotColor: '#06B6D4', badge: 'RBAC', shortcut: 'A' },
  { id: 'analytics', labelEn: 'Audit Analytics', labelTh: 'วิเคราะห์การตรวจสอบ', icon: TrendingUp, dotColor: '#10B981', badge: 'TRENDS', shortcut: 'Y' },
  { id: 'settings', labelEn: 'Settings', labelTh: 'ผู้ดูแลชาวไทย', icon: Settings, dotColor: '#71717A', shortcut: '=' },
];

export const Navigation: React.FC<NavigationProps> = ({
  currentView,
  onSelectView,
  onOpenCertificate,
  onOpenForensicDossier,
  onOpenChecklist,
  onOpenLegalSearch,
  onOpenCommandSearch,
  onOpenShortcuts,
  onOpenGitHubPwa,
  onOpenEventsSidebar,
  eventsCount = 0,
  isAudioActive,
  onToggleAudio,
  onCaptureSnapshot,
  isSystemActivityFrozen = false,
  onToggleFreezeSystemActivity,
  isForensicAuditMode = false,
  onToggleForensicAuditMode,
  sealCount,
  isSnapshotIncrementing = false,
  isSidebarOpen = false,
  onToggleSidebar,
  onTriggerLoginLoader,
  onOpenWebAuthn,
  isCopilotOpen: externalIsCopilotOpen,
  onToggleCopilot,
  onOpenUpgradeCycle,
}) => {
  const [carrierData, setCarrierData] = useState<{ volume: number; wavePath: string; frequency: number }>({
    volume: 0,
    wavePath: 'M 0 10 Q 25 10, 50 10 T 100 10',
    frequency: 882,
  });

  const displaySealCount = sealCount || SYSTEM_METADATA.canonicalSeals || 14902;
  const [highlightKey, setHighlightKey] = useState<number>(0);
  const [isSealHighlighting, setIsSealHighlighting] = useState<boolean>(false);
  const [internalIsCopilotOpen, setInternalIsCopilotOpen] = useState<boolean>(false);
  const effectiveIsCopilotOpen = externalIsCopilotOpen !== undefined ? externalIsCopilotOpen : internalIsCopilotOpen;
  const prevCountRef = useRef<number>(displaySealCount);

  // Real-time HSM Cluster State Subscription for Telemetry Quorum Indicator & Simulator
  const [hsmClusterState, setHsmClusterState] = useState<HsmClusterState>(() =>
    hsmClusterService.getState()
  );
  const [session, setSession] = useState<AuthenticatedSession | null>(() =>
    sessionService.getCurrentSession()
  );

  useEffect(() => {
    const unsubHsm = hsmClusterService.subscribe((state) => {
      setHsmClusterState(state);
    });
    const unsubSession = sessionService.subscribe((s) => {
      setSession(s);
    });
    return () => {
      unsubHsm();
      unsubSession();
    };
  }, []);

  // Tab Strip Refs for Auto-Centering and Horizontal Smooth Scrolling
  const tabsContainerRef = useRef<HTMLDivElement | null>(null);
  const activeTabRef = useRef<HTMLButtonElement | null>(null);

  // Auto-scroll active tab into center view
  useEffect(() => {
    if (activeTabRef.current) {
      activeTabRef.current.scrollIntoView({
        behavior: 'smooth',
        inline: 'center',
        block: 'nearest',
      });
    }
  }, [currentView]);

  const scrollTabs = (direction: 'left' | 'right') => {
    if (tabsContainerRef.current) {
      playTone(540, 0.04);
      const scrollAmount = direction === 'left' ? -260 : 260;
      tabsContainerRef.current.scrollBy({ left: scrollAmount, behavior: 'smooth' });
    }
  };

  // Trigger animation on snapshot capture / seal count change
  useEffect(() => {
    if (prevCountRef.current !== displaySealCount || isSnapshotIncrementing) {
      prevCountRef.current = displaySealCount;
      setIsSealHighlighting(true);
      setHighlightKey((k) => k + 1);
      const timer = setTimeout(() => {
        setIsSealHighlighting(false);
      }, 1600);
      return () => clearTimeout(timer);
    }
  }, [displaySealCount, isSnapshotIncrementing]);

  const handleCaptureSnapshotWithAnimation = () => {
    setIsSealHighlighting(true);
    setHighlightKey((k) => k + 1);
    playTone(740, 0.08);
    if (onCaptureSnapshot) {
      onCaptureSnapshot();
    }
    setTimeout(() => {
      setIsSealHighlighting(false);
    }, 1600);
  };

  // Frequency-reactive visualizer animation loop
  useEffect(() => {
    let animId: number;
    let phase = 0;

    const updateWave = () => {
      phase += 0.15;
      const snapshot = getHarmonicCarrierSnapshot();
      const isActive = isAudioActive && snapshot.isActive;
      const vol = isActive ? Math.max(0.04, snapshot.volume * 4) : 0;
      const freq = snapshot.frequency || 882;

      // Generate dynamic SVG cubic bezier wave path matching real-time harmonic volume
      const points: string[] = [];
      const width = 80;
      const height = 20;
      const midY = height / 2;
      const amplitude = isActive ? Math.min(8.5, 2.5 + vol * 30) : 1;

      points.push(`M 0 ${midY}`);
      const segments = 6;
      for (let i = 1; i <= segments; i++) {
        const x = (i / segments) * width;
        const sineOffset = Math.sin(phase + i * 1.2) * amplitude;
        const prevX = ((i - 1) / segments) * width;
        const cp1X = prevX + (x - prevX) / 2;
        const cp1Y = midY + (i % 2 === 0 ? sineOffset : -sineOffset);
        points.push(`Q ${cp1X} ${cp1Y}, ${x} ${midY}`);
      }

      setCarrierData({
        volume: vol,
        wavePath: points.join(' '),
        frequency: freq,
      });

      animId = requestAnimationFrame(updateWave);
    };

    animId = requestAnimationFrame(updateWave);
    return () => cancelAnimationFrame(animId);
  }, [isAudioActive]);
  return (
    <header className="sticky top-0 z-40 bg-gradient-to-r from-[#070914]/95 via-[#0b0e1e]/90 to-[#070914]/95 backdrop-blur-3xl border-b border-cyan-500/20 transition-all shadow-[0_8px_30px_-10px_rgba(6,182,212,0.15)] relative overflow-hidden">
      {/* Real-time Header Notification Alert for HSM Quorum Degradation (<80% / <8/10) */}
      <HsmQuorumAlertBanner />

      {/* Ambient Top Glow */}
      <div className="absolute top-0 left-0 w-full h-[1px] bg-gradient-to-r from-transparent via-cyan-400/40 to-transparent" />
      <div className="absolute top-0 left-1/4 w-1/2 h-16 bg-cyan-500/5 rounded-b-full blur-3xl pointer-events-none" />

      {/* Top Header Bar */}
      <div className="relative z-10 max-w-[1720px] mx-auto px-2.5 sm:px-4 md:px-6 py-2 flex items-center justify-between gap-2 sm:gap-4 overflow-hidden">
        {/* Left Brand Identity & Sidebar Toggle */}
        <div className="flex items-center gap-2 sm:gap-3 shrink-0 min-w-0">
          {/* Sidebar OPEN/CLOSE Toggle Button */}
          <button
            onClick={() => {
              playTone(isSidebarOpen ? 480 : 720, 0.05);
              onToggleSidebar?.();
            }}
            className={`flex items-center gap-1.5 sm:gap-2 px-2.5 sm:px-3 py-2 rounded-xl border transition-all shadow-sm select-none group shrink-0 cursor-pointer ${
              isSidebarOpen
                ? 'bg-cyan-500/20 text-cyan-200 border-cyan-400/50 shadow-[0_0_15px_rgba(6,182,212,0.25)]'
                : 'bg-black/40 hover:bg-white/10 text-zinc-300 hover:text-white border-white/10 hover:border-cyan-500/30'
            }`}
            title="Toggle Sidebar / เปิด-ปิดเมนูข้าง (Ctrl+B or [)"
          >
            {isSidebarOpen ? (
              <PanelLeftClose className="w-4 h-4 text-cyan-400 group-hover:scale-110 transition-transform" />
            ) : (
              <Menu className="w-4 h-4 text-zinc-300 group-hover:text-cyan-400 group-hover:scale-110 transition-transform" />
            )}
            <span className="hidden sm:inline font-mono text-xs font-semibold">
              {isSidebarOpen ? 'Menu (Open)' : 'Menu'}
            </span>
          </button>

          <div className="relative flex items-center justify-center shrink-0">
            <ZyrquenIcon size={42} />
            <span className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 sm:w-3 sm:h-3 rounded-full bg-emerald-500 border-2 border-[#070914] shadow-[0_0_8px_#10B981]" />
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-1.5 sm:gap-2">
              <span className="font-mono font-bold text-xs sm:text-base tracking-widest text-white uppercase whitespace-nowrap">
                ZYRQUEN <span className="text-cyan-400">Ω∞</span>
              </span>
              <button
                type="button"
                onClick={() => {
                  playTone(880, 0.05);
                  onOpenUpgradeCycle?.();
                }}
                className="hidden md:inline-flex items-center gap-1 px-2 py-0.5 text-[10px] font-mono rounded-full bg-cyan-950/60 hover:bg-cyan-900/80 text-cyan-300 hover:text-cyan-100 border border-cyan-500/40 hover:border-cyan-400 shadow-sm shrink-0 cursor-pointer transition-all active:scale-95"
                title="Sovereign Consensus Upgrade Cycle (อัปเกรดระบบ)"
              >
                <span>v1.2.1 LTS</span>
                <span className="text-[9px] px-1 rounded bg-cyan-500/20 text-cyan-200">🚀 อัปเกรด</span>
              </button>
              <span className="hidden 2xl:inline-flex px-2 py-0.5 text-[10px] font-mono rounded-full bg-emerald-950/60 text-emerald-300 border-emerald-500/40 shadow-sm items-center gap-1.5 shrink-0">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                SSoT MUTATION = 0
              </span>
            </div>
            <div className="flex items-center gap-1.5 sm:gap-2 text-[10px] sm:text-[11px] text-zinc-400 font-mono mt-0.5">
              <button
                onClick={() => {
                  playTone(840, 0.05);
                  onTriggerLoginLoader?.('login');
                }}
                className="text-cyan-100/80 hover:text-cyan-300 font-medium hover:underline flex items-center gap-1 cursor-pointer truncate max-w-[140px] sm:max-w-[240px] md:max-w-none"
                title="Trigger Sovereign Quantum Login & Warp Ingress Loader"
              >
                <span className="truncate">🇹🇭 นายยุทธภูมิ พากเพียร (#EP-SOVEREIGN-01)</span>
                <span className="hidden sm:inline-block px-1.5 py-0.2 rounded bg-cyan-950 border-cyan-500/40 text-[9px] text-cyan-300 shrink-0">
                  LOGIN/WARP
                </span>
              </button>
              <span className="hidden sm:inline text-zinc-600">•</span>
              <span className="hidden lg:inline text-zinc-500 tracking-wider shrink-0">ROOT: <span className="text-zinc-400">909ab814...fa4c68</span></span>
            </div>
          </div>
        </div>

        {/* Center Live Telemetry Gauges with Progressive Green Highlight on Snapshot */}
        <div className="hidden 2xl:flex items-center gap-4 bg-[#0a0f1e] border-cyan-500/20 px-5 py-2 rounded-2xl shadow-inner backdrop-blur-md shrink-0">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
            <span className="text-[11px] font-mono text-zinc-500">QOps:</span>
            <span className="text-[11px] font-mono text-cyan-300 font-bold tracking-wide">{SYSTEM_METADATA.qOpsTelemetry} QOps/s</span>
          </div>
          <div className="w-[1px] h-3.5 bg-white/10" />
          <div className="flex items-center gap-2">
            <span className="text-[11px] font-mono text-zinc-500">Coherence:</span>
            <span className="text-[11px] font-mono text-violet-300 font-bold tracking-wide">{SYSTEM_METADATA.coherence}</span>
          </div>
          <div className="w-[1px] h-3.5 bg-white/10" />
          <div className="flex items-center gap-2">
            <span className="text-[11px] font-mono text-zinc-500">Cryo:</span>
            <span className="text-[11px] font-mono text-amber-300 font-bold tracking-wide">{SYSTEM_METADATA.cryoTemp}</span>
          </div>
          <div className="w-[1px] h-3.5 bg-white/10" />
          {/* HSM Quorum Telemetry with Drop Simulator */}
          <button
            type="button"
            id="btn-hsm-quorum-telemetry"
            onClick={() => {
              playTone(420, 0.05);
              if (hsmClusterState.isDegraded) {
                hsmClusterService.remediateCluster();
              } else {
                hsmClusterService.simulateDegradation(7); // Simulate drop to 7/10 (<80%)
              }
            }}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg border text-xs font-mono cursor-pointer transition-all active:scale-95 ${
              hsmClusterState.isDegraded
                ? 'bg-red-950/80 border-red-500/80 text-red-200 animate-pulse shadow-[0_0_15px_rgba(239,68,68,0.5)]'
                : 'bg-black/40 hover:bg-black/60 border-white/10 hover:border-cyan-500/40 text-zinc-300'
            }`}
            title={
              hsmClusterState.isDegraded
                ? `⚠️ Quorum compromised at ${hsmClusterState.activeNodes}/${hsmClusterState.totalNodes} (${hsmClusterState.quorumPercentage}%)! Click to restore 10/10`
                : 'HSM Cluster Deca-Key Quorum: 10/10 (Click to simulate quorum degradation to 7/10)'
            }
          >
            <ShieldCheck
              className={`w-3.5 h-3.5 ${
                hsmClusterState.isDegraded ? 'text-red-400 animate-bounce' : 'text-cyan-400'
              }`}
            />
            <span className="text-[10px] text-zinc-400">HSM Quorum:</span>
            <span
              className={`text-[10px] font-bold ${
                hsmClusterState.isDegraded ? 'text-red-400' : 'text-emerald-400'
              }`}
            >
              {hsmClusterState.activeNodes}/{hsmClusterState.totalNodes}
            </span>
            {hsmClusterState.isDegraded && (
              <span className="px-1 py-0.2 rounded bg-red-500 text-[8px] font-extrabold text-black uppercase">
                &lt;80% ALERT
              </span>
            )}
          </button>
          <div className="w-[1px] h-3.5 bg-white/10" />
          
          {/* Verified Seals Counter with Framer Motion and Progressive Green Highlight */}
          <motion.div
            layout
            layoutId="nav-verified-seals-counter"
            animate={{
              scale: isSealHighlighting ? [1, 1.08, 1] : 1,
              backgroundColor: isSealHighlighting ? 'rgba(16, 185, 129, 0.25)' : 'rgba(0, 0, 0, 0)',
              borderColor: isSealHighlighting ? 'rgba(52, 211, 153, 0.6)' : 'rgba(255, 255, 255, 0)',
              boxShadow: isSealHighlighting
                ? '0 0 25px rgba(16, 185, 129, 0.7), inset 0 0 10px rgba(16, 185, 129, 0.3)'
                : 'none',
            }}
            transition={{
              layout: { duration: 0.45, ease: [0.16, 1, 0.3, 1] },
              duration: 0.5,
              ease: 'easeOut',
            }}
            className="flex items-center gap-2 px-2.5 py-1 rounded-xl border-transparent transition-colors relative overflow-hidden"
          >
            {isSealHighlighting && (
              <motion.div
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 1.2 }}
                className="absolute inset-0 bg-emerald-400/20 blur-sm pointer-events-none rounded-xl"
              />
            )}
            <motion.span layout className="text-[11px] font-mono text-zinc-400 font-medium relative z-10">
              Verified Seals:
            </motion.span>
            <AnimatePresence mode="wait">
              <motion.span
                layout
                key={`${displaySealCount}-${highlightKey}`}
                initial={{ y: -8, opacity: 0, scale: 0.9 }}
                animate={{ y: 0, opacity: 1, scale: 1 }}
                exit={{ y: 8, opacity: 0, scale: 1.1 }}
                transition={{
                  layout: { duration: 0.35, ease: 'easeOut' },
                  duration: 0.35,
                  ease: 'easeOut',
                }}
                className={`text-[11px] font-mono font-bold tracking-wide flex items-center gap-1.5 relative z-10 ${
                  isSealHighlighting ? 'text-emerald-200 drop-shadow-[0_0_12px_#10B981]' : 'text-emerald-400'
                }`}
              >
                <span>{displaySealCount.toLocaleString()}</span>
                <span className="text-zinc-500 font-normal">/ {SYSTEM_METADATA.canonicalSeals.toLocaleString()}</span>
                {isSealHighlighting && (
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                )}
              </motion.span>
            </AnimatePresence>
          </motion.div>
        </div>

        {/* Global Search Bar (Quick Filter for System Events, Forensic Audit Logs, Laws) */}
        <div className="hidden md:flex flex-1 max-w-sm lg:max-w-md mx-2">
          <TopNavGlobalSearchBar
            onSelectView={onSelectView}
            onOpenForensicDossier={onOpenForensicDossier}
            onOpenEventsSidebar={onOpenEventsSidebar}
            onOpenLegalSearch={onOpenLegalSearch}
          />
        </div>

        {/* Real-time GitHub Sync Status Indicator (Commit hash, repository & deployment timestamp) */}
        <div className="hidden md:flex shrink-0">
          <GitHubSyncWarningNav />
        </div>

        {/* Right Actions */}
        <div className="flex items-center gap-1 sm:gap-2 shrink-0">
          {/* Sovereign Upgrade Cycle Trigger Button */}
          {onOpenUpgradeCycle && (
            <button
              type="button"
              onClick={() => {
                playTone(880, 0.05);
                onOpenUpgradeCycle();
              }}
              className="flex md:hidden items-center gap-1 px-2 py-1 rounded-xl bg-gradient-to-r from-cyan-500/25 to-blue-600/25 hover:from-cyan-500/35 hover:to-blue-600/35 border border-cyan-400/50 text-cyan-200 font-mono text-[11px] font-bold shadow-sm active:scale-95 transition-all cursor-pointer shrink-0"
              title="Sovereign Upgrade Cycle (อัปเกรดระบบ)"
            >
              <Sparkles className="w-3.5 h-3.5 text-cyan-300 animate-pulse" />
              <span>อัปเกรด</span>
            </button>
          )}

          {/* PWA Install & Copilot Assistant Layer (Sovereign Epoch #849202) Trigger Button */}
          <PWAInstallButton />

          {/* Copilot Assistant Layer (Sovereign Epoch #849202) Trigger Button */}
          <button
            id="btn-nav-copilot-trigger"
            onClick={() => {
              playTone(740, 0.06);
              if (onToggleCopilot) {
                onToggleCopilot();
              } else {
                setInternalIsCopilotOpen(!internalIsCopilotOpen);
              }
            }}
            className={`group flex items-center gap-1 sm:gap-1.5 px-2 sm:px-3 py-1.5 rounded-xl border font-mono text-xs transition-all cursor-pointer active:scale-95 shrink-0 ${
              effectiveIsCopilotOpen
                ? 'bg-cyan-500 text-black border-cyan-400 shadow-[0_0_15px_rgba(6,182,212,0.4)]'
                : 'bg-purple-950/40 hover:bg-purple-900/50 border-purple-500/30 hover:border-purple-400/60 text-purple-200 hover:text-white shadow-[0_0_12px_rgba(168,85,247,0.15)] hover:shadow-[0_0_18px_rgba(168,85,247,0.3)]'
            }`}
            title="เปิด/ปิด Copilot Assistant Layer (Sovereign Epoch #849202)"
          >
            <span className="text-sm group-hover:scale-110 transition-transform">🧠</span>
            <span className="hidden sm:inline font-bold tracking-wide">Copilot</span>
            <span className={`px-1 sm:px-1.5 py-0.2 rounded font-mono text-[9px] border ${
              effectiveIsCopilotOpen ? 'bg-black/20 text-black border-black/30 font-bold' : 'bg-purple-500/20 text-purple-300 border-purple-500/30'
            }`}>Ω1</span>
          </button>

          {/* Sovereign WebAuthn Biometric & Login Trigger Button */}
          {onOpenWebAuthn && (
            <button
              id="btn-nav-webauthn-login"
              onClick={() => {
                playTone(720, 0.08);
                onOpenWebAuthn();
              }}
              className={`group flex items-center gap-1 sm:gap-1.5 px-2 sm:px-3 py-1.5 rounded-xl border font-mono text-xs transition-all cursor-pointer active:scale-95 shadow-sm shrink-0 ${
                session && session.status === 'ACTIVE'
                  ? 'bg-gradient-to-r from-emerald-500/25 to-teal-500/20 border-emerald-500/50 hover:border-emerald-400 text-emerald-200 shadow-[0_0_12px_rgba(16,185,129,0.15)]'
                  : 'bg-gradient-to-r from-zinc-900 to-zinc-950 border-zinc-700 hover:border-zinc-500 text-zinc-300'
              }`}
              title={
                session && session.status === 'ACTIVE'
                  ? `เซสชันที่ได้รับการรับรอง: ${session.userDisplayName} (${session.fipsLevel}) — คลิกเพื่อจัดการหรือยืนยันตัวตนซ้ำ`
                  : 'เข้าสู่ระบบด้วย WebAuthn Passkey (พ.ร.บ. ธุรกรรมฯ ม.๙ / ม.๒๖)'
              }
            >
              <Fingerprint className={`w-3.5 h-3.5 ${session && session.status === 'ACTIVE' ? 'text-emerald-400' : 'text-zinc-400'} group-hover:scale-110 transition-transform`} />
              <span className="hidden sm:inline font-bold tracking-wide">
                {session && session.status === 'ACTIVE' ? 'EP-01' : 'Login'}
              </span>
              <span className={`hidden md:inline px-1 py-0.2 rounded font-mono text-[9px] border font-bold ${
                session && session.status === 'ACTIVE'
                  ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
                  : 'bg-zinc-800 text-zinc-400 border-zinc-700'
              }`}>
                {session && session.status === 'ACTIVE' ? 'AUTH' : 'FIPS'}
              </span>
            </button>
          )}

          {/* Global Theme Switcher (Terminal Green / Deep Space Violet / Sovereign Cyan) */}
          <div id="theme-switcher-nav" className="shrink-0">
            <ThemeSwitcher compact />
          </div>

          {/* Dedicated Global Command Search Trigger (System Events, Legal, Navigation) */}
          <button
            id="btn-nav-command-search"
            onClick={() => {
              playTone(680, 0.08);
              if (onOpenCommandSearch) {
                onOpenCommandSearch();
              } else {
                onOpenLegalSearch();
              }
            }}
            className="hidden lg:flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-cyan-950/50 hover:bg-cyan-500/20 border-cyan-500/40 hover:border-cyan-400/60 text-cyan-300 hover:text-cyan-100 font-mono text-xs transition-all shadow-sm cursor-pointer active:scale-95"
            title="Global Command Search (System Events, Legal Triggers, Views) [⌘K / Ctrl+K]"
          >
            <Terminal className="w-3.5 h-3.5 text-cyan-400 group-hover:scale-110 transition-transform" />
            <span className="hidden xl:inline font-bold">Commands</span>
            <kbd className="hidden sm:inline px-1.5 py-0.2 text-[9px] rounded bg-cyan-500/20 text-cyan-300 font-mono border-cyan-500/30">⌘K</kbd>
          </button>

          {/* Dedicated Legal & PQC Search Trigger Button with Search Icon */}
          <button
            id="btn-nav-legal-search"
            onClick={() => {
              playTone(680, 0.08);
              onOpenLegalSearch();
            }}
            className="hidden 2xl:flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-slate-900/90 hover:bg-slate-800 border-slate-700/60 hover:border-cyan-500/40 text-zinc-300 hover:text-white font-mono text-xs transition-all shadow-sm cursor-pointer active:scale-95"
            title="Search Thai Laws & Cryptographic Standards"
          >
            <Search className="w-3.5 h-3.5 text-zinc-400 group-hover:text-cyan-400 group-hover:scale-110 transition-transform" />
            <span className="hidden 2xl:inline font-bold">Laws</span>
          </button>

          {/* Keyboard Shortcuts Trigger Button */}
          <button
            onClick={() => {
              playTone(620, 0.06);
              onOpenShortcuts();
            }}
            className="hidden xl:flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-black/30 hover:bg-white/10 border-white/10 hover:border-white/20 text-zinc-400 hover:text-white font-mono text-xs transition-colors shadow-sm"
            title="Global Keyboard Shortcuts & Fast Navigator (? or Ctrl+/)"
          >
            <Keyboard className="w-4 h-4 text-zinc-400" />
            <span className="hidden lg:inline text-[11px] font-medium">Shortcuts</span>
            <kbd className="hidden sm:inline px-1.5 py-0.5 text-[10px] rounded bg-white/10 text-zinc-300 font-mono border-white/10">?</kbd>
          </button>

          {/* System Events Sidebar Trigger */}
          {onOpenEventsSidebar && (
            <button
              onClick={() => {
                playTone(640, 0.05);
                onOpenEventsSidebar();
              }}
              className="relative p-1.5 sm:p-2 rounded-xl bg-black/30 hover:bg-white/10 border-white/10 hover:border-white/20 text-zinc-300 hover:text-white font-mono text-xs transition-colors flex items-center gap-1.5 shadow-sm shrink-0"
              title="Toggle System Events Activity Feed (Shift+E)"
            >
              <Bell className="w-4 h-4 text-cyan-400" />
              {eventsCount > 0 && (
                <span className="absolute -top-1.5 -right-1.5 px-1.5 py-0.5 rounded-full bg-cyan-500 text-black border-2 border-[#070914] text-[9px] font-bold shadow-[0_0_10px_rgba(6,182,212,0.5)]">
                  {eventsCount}
                </span>
              )}
            </button>
          )}

          {/* Hardware Snapshot Trigger with Animated Counter Effect */}
          {onCaptureSnapshot && (
            <button
              onClick={handleCaptureSnapshotWithAnimation}
              className="hidden 2xl:flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-950/40 hover:bg-emerald-500/20 border-emerald-500/30 hover:border-emerald-400/50 text-emerald-300 font-mono text-xs transition-all shadow-[0_0_12px_rgba(16,185,129,0.15)] active:scale-95"
              title="Capture Hardware Telemetry Snapshot (Increments Verified Seals with Progressive Green Highlight)"
            >
              <Camera className="w-3.5 h-3.5 text-emerald-400" />
              <span className="hidden xl:inline font-bold">Quick Snapshot</span>
            </button>
          )}

          {/* Forensic Audit Mode Toggle (Overlays Metadata Hashes & PQC Signatures) */}
          {onToggleForensicAuditMode && (
            <button
              onClick={() => {
                playTone(isForensicAuditMode ? 440 : 760, 0.08);
                onToggleForensicAuditMode();
              }}
              className={`hidden xl:flex items-center gap-1.5 px-3 py-1.5 rounded-xl border font-mono text-xs transition-all shadow-sm ${
                isForensicAuditMode
                  ? 'bg-purple-500/25 text-purple-200 border-purple-500/60 shadow-[0_0_18px_rgba(168,85,247,0.4)] font-bold ring-1 ring-purple-400/40'
                  : 'bg-black/30 hover:bg-purple-500/10 border-white/10 hover:border-purple-500/30 text-zinc-400 hover:text-purple-200'
              }`}
              title={
                isForensicAuditMode
                  ? 'Forensic Audit Mode: Active (Hashes & PQC Signature Statuses Overlaid)'
                  : 'Toggle Forensic Audit Mode: Overlay metadata hashes and PQC signature statuses on dashboard cards'
              }
            >
              <Fingerprint
                className={`w-3.5 h-3.5 ${
                  isForensicAuditMode ? 'text-purple-300 animate-pulse' : 'text-zinc-400'
                }`}
              />
              <span className="hidden sm:inline">
                {isForensicAuditMode ? 'FORENSIC AUDIT' : 'Forensic Mode'}
              </span>
              {isForensicAuditMode && (
                <span className="w-1.5 h-1.5 rounded-full bg-purple-400 animate-ping" />
              )}
            </button>
          )}

          {/* Global Freeze System Activity Toggle (State-Preservation Maintenance Mode) */}
          {onToggleFreezeSystemActivity && (
            <button
              onClick={() => {
                playTone(isSystemActivityFrozen ? 580 : 340, 0.08);
                onToggleFreezeSystemActivity();
              }}
              className={`hidden xl:flex items-center gap-1.5 px-3 py-1.5 rounded-xl border font-mono text-xs transition-all shadow-sm ${
                isSystemActivityFrozen
                  ? 'bg-amber-500/20 text-amber-200 border-amber-500/50 shadow-[0_0_16px_rgba(245,158,11,0.35)] animate-pulse font-bold'
                  : 'bg-black/30 hover:bg-cyan-500/10 border-white/10 hover:border-cyan-500/30 text-zinc-400 hover:text-cyan-200'
              }`}
              title={
                isSystemActivityFrozen
                  ? 'System Activity Frozen: Telemetry capture & audio clock paused (Click to Resume)'
                  : 'Freeze System Activity: Arms state-preservation maintenance mode'
              }
            >
              <Snowflake
                className={`w-3.5 h-3.5 ${
                  isSystemActivityFrozen ? 'text-amber-400 animate-spin' : 'text-zinc-400'
                }`}
                style={{ animationDuration: isSystemActivityFrozen ? '8s' : '0s' }}
              />
              <span className="hidden sm:inline">
                {isSystemActivityFrozen ? 'ACTIVITY FROZEN' : 'Freeze Activity'}
              </span>
              {isSystemActivityFrozen && (
                <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-ping" />
              )}
            </button>
          )}

          {/* Frequency-Reactive 882Hz Harmonic Carrier Visualizer */}
          <div
            onClick={() => {
              playTone(600, 0.08);
              onToggleAudio();
            }}
            className={`hidden lg:flex cursor-pointer px-3 py-1.5 rounded-xl border transition-all text-xs font-mono items-center gap-2 ${
              isAudioActive
                ? 'bg-cyan-950/50 border-cyan-500/40 text-cyan-300 shadow-[0_0_15px_rgba(6,182,212,0.25)]'
                : 'bg-black/30 border-white/10 hover:border-white/20 text-zinc-400 hover:text-zinc-200 shadow-sm'
            }`}
            title={isAudioActive ? '882 Hz Harmonic Carrier Active (Click to toggle/mute)' : 'Click to start 882 Hz Post-Quantum Clock Pulse Carrier'}
          >
            <div className="flex items-center gap-1.5">
              {isAudioActive ? (
                <Volume2 className="w-4 h-4 text-cyan-400 animate-pulse" />
              ) : (
                <VolumeX className="w-4 h-4 text-zinc-500" />
              )}
              <span className="hidden md:inline text-[11px] font-bold tracking-wide">
                {isAudioActive ? '882 Hz' : 'SYNTH'}
              </span>
            </div>

            {/* Reactive SVG Wave Animation */}
            <div className="w-16 h-5 flex items-center justify-center overflow-hidden">
              <svg viewBox="0 0 80 20" className="w-full h-full">
                <defs>
                  <linearGradient id="carrierWaveGlow" x1="0%" y1="0%" x2="100%" y2="0%">
                    <stop offset="0%" stopColor="#06b6d4" stopOpacity="0.4" />
                    <stop offset="50%" stopColor="#38bdf8" stopOpacity="1" />
                    <stop offset="100%" stopColor="#10b981" stopOpacity="0.4" />
                  </linearGradient>
                  <filter id="waveGlowBlur">
                    <feGaussianBlur stdDeviation="1.5" result="coloredBlur"/>
                    <feMerge>
                      <feMergeNode in="coloredBlur"/>
                      <feMergeNode in="SourceGraphic"/>
                    </feMerge>
                  </filter>
                </defs>
                <path
                  d={carrierData.wavePath}
                  fill="none"
                  stroke={isAudioActive ? 'url(#carrierWaveGlow)' : 'rgba(255,255,255,0.15)'}
                  strokeWidth={isAudioActive ? '2' : '1.2'}
                  strokeLinecap="round"
                  filter={isAudioActive ? 'url(#waveGlowBlur)' : 'none'}
                />
              </svg>
            </div>

            {isAudioActive && (
              <span className="hidden xl:inline text-[10px] text-cyan-300 font-mono font-semibold">
                {Math.round(carrierData.volume * 100)}%
              </span>
            )}
          </div>

          {/* Master Forensic Dossier Button (Exhibits จพ.๐๑-๐๗ with 1-Click PDF Export) */}
          {onOpenForensicDossier && (
            <button
              onClick={() => {
                playTone(740, 0.08);
                onOpenForensicDossier();
              }}
              className="hidden lg:flex group items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-purple-500/20 via-indigo-500/15 to-cyan-500/20 border border-purple-500/40 text-purple-200 hover:text-white font-mono text-xs hover:border-purple-400/60 transition-all shadow-[0_0_15px_rgba(168,85,247,0.2)] hover:shadow-[0_0_20px_rgba(168,85,247,0.35)] active:scale-95 cursor-pointer ml-1"
              title="เปิดสำนวนพยานหลักฐานดิจิทัลสำหรับยื่นศาล (Master Forensic Dossier DOC-SOV-HSM-1010-2026-V9 พร้อม Export PDF/JSON)"
            >
              <Scale className="w-4 h-4 text-purple-400 group-hover:scale-110 transition-transform" />
              <span className="font-bold tracking-wide">Dossier</span>
              <span className="hidden xl:inline-block px-1.5 py-0.2 rounded-full bg-purple-500/25 text-[9px] text-purple-300 border border-purple-500/30">จพ.๐๑-๐๗</span>
            </button>
          )}

          {/* PWA Mobile & Offline Hub Button */}
          {onOpenGitHubPwa && (
            <button
              onClick={() => {
                playTone(680, 0.08);
                onOpenGitHubPwa();
              }}
              className="hidden xl:flex group items-center gap-1.5 px-3 py-1.5 rounded-xl bg-cyan-950/40 hover:bg-cyan-900/50 border border-cyan-500/40 text-cyan-300 hover:text-cyan-100 font-mono text-xs hover:border-cyan-400/60 transition-all shadow-sm active:scale-95 cursor-pointer ml-1"
              title="PWA Mobile Install & GitHub Synchronization Center"
            >
              <Smartphone className="w-4 h-4 text-cyan-400 group-hover:scale-110 transition-transform" />
              <span className="font-bold tracking-wide">PWA / Mobile</span>
            </button>
          )}

          {onOpenChecklist && (
            <button
              onClick={() => {
                playTone(760, 0.08);
                onOpenChecklist();
              }}
              className="hidden md:flex group items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-emerald-500/20 via-teal-500/15 to-cyan-500/20 border-emerald-500/40 text-emerald-300 hover:text-emerald-100 font-mono text-xs hover:border-emerald-400/60 transition-all shadow-[0_0_15px_rgba(16,185,129,0.2)] hover:shadow-[0_0_20px_rgba(16,185,129,0.35)] active:scale-95 cursor-pointer ml-1"
              title="เปิดระบบตรวจเช็คระบบและพยานหลักฐานดิจิทัลทีละขั้นตอน (System Check-Up & Step-by-Step Stepper)"
            >
              <FileCheck2 className="w-4 h-4 text-emerald-400 group-hover:scale-110 transition-transform" />
              <span className="font-bold tracking-wide">Check-Up</span>
              <span className="hidden sm:inline-block px-1.5 py-0.2 rounded-full bg-emerald-500/25 text-[9px] text-emerald-300 border-emerald-500/30">16 ขั้น</span>
            </button>
          )}

          <button
            onClick={() => {
              playTone(720, 0.1);
              onOpenCertificate();
            }}
            className="group flex items-center gap-1.5 sm:gap-2 px-2.5 sm:px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-amber-500/20 via-violet-500/15 to-cyan-500/20 border-amber-500/40 text-amber-300 hover:text-amber-100 font-mono text-xs hover:border-amber-400/60 transition-all shadow-[0_0_15px_rgba(245,158,11,0.15)] hover:shadow-[0_0_20px_rgba(245,158,11,0.25)] shrink-0"
            title="Inspect Gold Master Sovereign Certificate"
          >
            <Award className="w-4 h-4 text-amber-400 group-hover:scale-110 transition-transform" />
            <span className="hidden sm:inline font-bold tracking-wide">Gold Master</span>
            <span className="sm:hidden font-bold tracking-wide text-[10px]">Master</span>
          </button>
        </div>
      </div>

      {/* Navigation Tabs Strip with Scroll Chevrons & Edge Fades */}
      <div className="relative z-10 max-w-[1720px] mx-auto px-1 sm:px-4 border-t border-cyan-500/15 py-1.5 flex items-center gap-1">
        {/* Left Scroll Chevron */}
        <button
          type="button"
          onClick={() => scrollTabs('left')}
          className="hidden sm:flex items-center justify-center w-7 h-8 rounded-lg bg-[#0a0f1e] hover:bg-cyan-950 border-cyan-500/30 text-cyan-400 hover:text-cyan-200 transition-all shrink-0 cursor-pointer shadow-sm z-20"
          title="Scroll tabs left"
          aria-label="Scroll tabs left"
        >
          <ChevronLeft className="w-4 h-4" />
        </button>

        {/* Scrollable Container with Edge Masks */}
        <div className="relative flex-1 min-w-0 overflow-hidden">
          {/* Left Edge Mask */}
          <div className="absolute left-0 top-0 bottom-0 w-4 sm:w-6 bg-gradient-to-r from-[#070914] to-transparent pointer-events-none z-10" />

          <div
            ref={tabsContainerRef}
            className="overflow-x-auto scroll-smooth custom-scrollbar flex items-center gap-1.5 sm:gap-2 py-0.5 px-2 touch-pan-x"
          >
            {NAVIGATION_ITEMS.map((item) => {
              const Icon = item.icon;
              const isActive = currentView === item.id;
              return (
                <button
                  key={item.id}
                  ref={isActive ? activeTabRef : null}
                  onClick={() => {
                    playTone(isActive ? 880 : 540, 0.06);
                    onSelectView(item.id);
                  }}
                  className={`relative shrink-0 px-3 sm:px-3.5 py-2 rounded-xl font-mono text-xs flex items-center gap-2 whitespace-nowrap transition-all duration-200 select-none cursor-pointer ${
                    isActive
                      ? 'bg-[#0a0f1e] text-white border-cyan-400 shadow-[0_0_15px_rgba(6,182,212,0.25)] font-bold'
                      : 'bg-transparent text-zinc-400 hover:text-zinc-100 hover:bg-white/[0.06] border-white/5 hover:border-cyan-500/30'
                  }`}
                >
                  {isActive && (
                    <div className="absolute top-0 left-0 w-full h-[1px] bg-cyan-400" />
                  )}
                  <span
                    className={`w-1.5 h-1.5 rounded-full transition-transform shrink-0 ${
                      isActive ? 'scale-150 shadow-[0_0_8px_currentColor]' : 'opacity-60'
                    }`}
                    style={{ backgroundColor: item.dotColor, color: item.dotColor }}
                  />
                  <Icon className={`w-4 h-4 shrink-0 transition-colors ${isActive ? 'text-cyan-300' : 'text-zinc-500 group-hover:text-zinc-300'}`} />
                  <span className="font-semibold tracking-wide whitespace-nowrap" title={`${item.labelEn} — ${item.labelTh}`}>
                    {item.primaryTh ? item.labelTh : item.labelEn}
                  </span>
                  {item.badge && (
                    <span
                      className={`text-[9px] px-1.5 py-0.5 rounded font-mono font-bold tracking-wider shrink-0 ${
                        isActive ? 'bg-cyan-950 border-cyan-400 text-cyan-300' : 'bg-[#0a0f1e] text-zinc-500 border-white/10 group-hover:text-zinc-400'
                      }`}
                    >
                      {item.badge}
                    </span>
                  )}
                  {item.shortcut && (
                    <span className="hidden lg:group-hover:inline-block text-[8px] font-mono text-zinc-500 bg-black/50 px-1.5 py-0.5 rounded border-white/10 ml-1 shrink-0">
                      {item.shortcut}
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          {/* Right Edge Mask */}
          <div className="absolute right-0 top-0 bottom-0 w-4 sm:w-6 bg-gradient-to-l from-[#070914] to-transparent pointer-events-none z-10" />
        </div>

        {/* Right Scroll Chevron */}
        <button
          type="button"
          onClick={() => scrollTabs('right')}
          className="hidden sm:flex items-center justify-center w-7 h-8 rounded-lg bg-[#0a0f1e] hover:bg-cyan-950 border-cyan-500/30 text-cyan-400 hover:text-cyan-200 transition-all shrink-0 cursor-pointer shadow-sm z-20"
          title="Scroll tabs right"
          aria-label="Scroll tabs right"
        >
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>

      {/* Copilot Assistant Layer Drawer (Sovereign Epoch #849202) - Rendered locally only if not handled by root App */}
      {!onToggleCopilot && (
        <CopilotAssistantDrawer
          isOpen={effectiveIsCopilotOpen}
          onClose={() => setInternalIsCopilotOpen(false)}
          onNavigate={onSelectView}
        />
      )}
    </header>
  );
};
