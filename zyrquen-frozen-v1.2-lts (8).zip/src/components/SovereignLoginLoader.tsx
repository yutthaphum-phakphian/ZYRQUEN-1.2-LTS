import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { playTone, playAuditChime } from './AudioSynthesizer';

interface SovereignLoginLoaderProps {
  isOpen: boolean;
  onComplete: () => void;
  onCancel?: () => void;
  mode?: 'login' | 'register' | 'switch_tenant';
}

const HSM_SLOTS = [
  { id: 1, name: 'HSM-01', algo: 'ML-KEM-1024', status: 'LOCKED', color: '#06B6D4' },
  { id: 2, name: 'HSM-02', algo: 'ML-DSA-87', status: 'LOCKED', color: '#06B6D4' },
  { id: 3, name: 'HSM-03', algo: 'SLH-DSA', status: 'LOCKED', color: '#06B6D4' },
  { id: 4, name: 'HSM-04', algo: 'FIPS 140-3', status: 'LOCKED', color: '#D4AF37' },
  { id: 5, name: 'HSM-05', algo: 'ETDA Sec 9', status: 'LOCKED', color: '#D4AF37' },
  { id: 6, name: 'HSM-06', algo: 'PDPA Sec 26', status: 'LOCKED', color: '#D4AF37' },
  { id: 7, name: 'HSM-07', algo: 'CRYO 14.98mK', status: 'LOCKED', color: '#10B981' },
  { id: 8, name: 'HSM-08', algo: 'DAG-6-STAGE', status: 'LOCKED', color: '#10B981' },
  { id: 9, name: 'HSM-09', algo: 'Ω600_1000', status: 'LOCKED', color: '#8B5CF6' },
  { id: 10, name: 'HSM-10', algo: 'OMEGA-1 HQ', status: 'LOCKED', color: '#8B5CF6' },
];

const SOVEREIGN_PHASES = [
  { at: 10, title: 'Quantum Warp Stream Synchronizing...', tone: 520 },
  { at: 25, title: 'Dilithium-5 / ML-KEM-1024 Lattice Handshake Initialized', tone: 580 },
  { at: 45, title: 'Genesis Merkle Root #849202 Bound (14,902 Seals Verified)', tone: 640 },
  { at: 65, title: 'FIPS 140-3 Level 4 HSM 10/10 Quorum Attestation Signed', tone: 720 },
  { at: 85, title: 'Thai Legal Safe Harbor (ETDA & PDPA) Enclave Armed', tone: 800 },
  { at: 95, title: 'Ω600_1000 Sovereign Tenant Lattice Stabilized (Δ0.00% Drift)', tone: 880 },
  { at: 100, title: 'OMEGA INFINITY LOCKED — RUNTIME VERIFIED 100% GREEN', tone: 960 },
];

export const SovereignLoginLoader: React.FC<SovereignLoginLoaderProps> = ({
  isOpen,
  onComplete,
  onCancel,
  mode = 'login',
}) => {
  const [progress, setProgress] = useState<number>(0);
  const [phaseText, setPhaseText] = useState<string>('Initializing Sovereign Warp Runtime...');
  const [signedHsmCount, setSignedHsmCount] = useState<number>(0);
  const [currentEntropy, setCurrentEntropy] = useState<number>(0.0);
  const [warpSpeedQops, setWarpSpeedQops] = useState<number>(12480);
  const [isWarpFlash, setIsWarpFlash] = useState<boolean>(false);

  useEffect(() => {
    if (!isOpen) {
      setProgress(0);
      setSignedHsmCount(0);
      setIsWarpFlash(false);
      return;
    }

    playTone(440, 0.1);

    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          return 100;
        }

        const next = Math.min(100, prev + 3);
        
        // Update Signed HSM Count
        const currentSlot = Math.min(10, Math.floor((next / 100) * 10));
        setSignedHsmCount(currentSlot);

        // Update Phase Text & Audio Pitch
        const matchedPhase = [...SOVEREIGN_PHASES].reverse().find((p) => next >= p.at);
        if (matchedPhase) {
          setPhaseText(matchedPhase.title);
        }

        // Live Warp Metrics Jitter
        setWarpSpeedQops(12480 + Math.floor(Math.sin(next) * 520));

        if (next % 12 === 0) {
          playTone(480 + next * 4, 0.02);
        }

        if (next === 100) {
          playAuditChime();
          setIsWarpFlash(true);
          setTimeout(() => {
            onComplete();
          }, 900);
        }

        return next;
      });
    }, 90);

    return () => clearInterval(interval);
  }, [isOpen, onComplete]);

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-50 flex items-center justify-center bg-[#070a12] p-4 font-mono select-none"
      >
        {/* Holographic Warp Stream Particle Field */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute inset-0 bg-[#070a12] opacity-95" />
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] rounded-full border border-cyan-500/20 opacity-30 animate-pulse pointer-events-none" />
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full border border-[#D4AF37]/25 opacity-40 pointer-events-none" />
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[400px] h-[400px] rounded-full border border-emerald-500/20 opacity-40 pointer-events-none" />
        </div>

        {/* Central Quantum Warp Login Enclave */}
        <motion.div
          initial={{ scale: 0.92, y: 20 }}
          animate={{ scale: isWarpFlash ? 1.05 : 1, y: 0 }}
          transition={{ duration: 0.35 }}
          className="relative z-10 w-full max-w-2xl p-8 rounded-3xl bg-[#0a0f1e] border-2 border-[#D4AF37] shadow-2xl space-y-6 text-zinc-100"
        >
          {/* Sovereign Warp Header */}
          <div className="flex items-center justify-between border-b border-zinc-800 pb-4">
            <div className="flex items-center gap-3">
              <span className="text-3xl">🏛️</span>
              <div>
                <div className="flex items-center gap-2">
                  <h1 className="text-lg font-bold tracking-widest text-[#D4AF37] uppercase">
                    ZYRQUEN Ω∞ SOVEREIGN RUNTIME
                  </h1>
                  <span className="px-2 py-0.5 rounded bg-cyan-950 border border-cyan-500/50 text-cyan-300 text-[10px] font-bold">
                    FROZEN v1.2 LTS
                  </span>
                </div>
                <p className="text-xs text-zinc-400">
                  {mode === 'login'
                    ? 'Sovereign Multi-Pass Quantum Login & Warp Ingress'
                    : mode === 'register'
                    ? 'Registering Cryptographic Identity (#EP-SOVEREIGN-01)'
                    : 'Switching Sovereign Tenant Partition (Ω600_1000)'}
                </p>
              </div>
            </div>

            <div className="text-right">
              <span className="text-xs text-zinc-400">AUTHORITY</span>
              <div className="text-xs font-bold text-emerald-400">OMEGA-1 SUPREME</div>
            </div>
          </div>

          {/* Warp Stream Hologram Progress Bar */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs">
              <div className="flex items-center gap-2">
                <span className="text-cyan-400 font-bold">QUANTUM WARP STREAM:</span>
                <span className="text-zinc-400">{warpSpeedQops} qOps/s</span>
              </div>
              <span className="text-[#D4AF37] font-bold text-sm tracking-wider">
                {progress}% {progress === 100 ? '✅ LOCKED' : '⚡ STREAMING'}
              </span>
            </div>

            {/* Custom Solid Progress Track */}
            <div className="w-full h-5 bg-[#070a12] border border-cyan-500/40 rounded-full p-0.5 overflow-hidden">
              <motion.div
                className="h-full bg-cyan-400 rounded-full transition-all duration-100 relative"
                style={{ width: `${progress}%` }}
              >
                <div className="absolute top-0 right-0 bottom-0 w-4 bg-white opacity-80 animate-pulse rounded-r-full" />
              </motion.div>
            </div>
          </div>

          {/* Custodian HSM 10/10 Signatures Slots Grid */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs text-zinc-400">
              <span className="flex items-center gap-1.5">
                <span>🧊</span>
                <span className="font-bold text-zinc-200">REAL_HSM 10/10 QUORUM SEALS:</span>
              </span>
              <span className="text-emerald-400 font-bold">
                {signedHsmCount}/10 ATTESTED (FIPS 140-3 L4)
              </span>
            </div>

            <div className="grid grid-cols-5 gap-2">
              {HSM_SLOTS.map((slot) => {
                const isSigned = signedHsmCount >= slot.id;
                return (
                  <div
                    key={slot.id}
                    className={`p-2 rounded-xl border text-center transition-all duration-200 ${
                      isSigned
                        ? 'bg-[#070a12] border-emerald-500 text-emerald-300 shadow-md'
                        : 'bg-[#070a12] border-zinc-800 text-zinc-600'
                    }`}
                  >
                    <div className="text-[10px] font-bold">{slot.name}</div>
                    <div className="text-[8px] truncate">{slot.algo}</div>
                    <div className="mt-1 text-[9px] font-bold">
                      {isSigned ? '✅ SIGNED' : '⏳ QUEUED'}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* SSoT Drift & Genesis Merkle Indicators */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
            <div className="p-2.5 rounded-xl bg-[#070a12] border border-zinc-800">
              <div className="text-[10px] text-zinc-400">ENTROPY DRIFT</div>
              <div className="text-emerald-400 font-bold">Δ0.00% ZERO DRIFT</div>
            </div>
            <div className="p-2.5 rounded-xl bg-[#070a12] border border-zinc-800">
              <div className="text-[10px] text-zinc-400">MERKLE BLOCK</div>
              <div className="text-cyan-300 font-bold">#849202 (14.9K)</div>
            </div>
            <div className="p-2.5 rounded-xl bg-[#070a12] border border-zinc-800">
              <div className="text-[10px] text-zinc-400">TENANT BOUNDARY</div>
              <div className="text-[#D4AF37] font-bold">Ω600_1000</div>
            </div>
            <div className="p-2.5 rounded-xl bg-[#070a12] border border-zinc-800">
              <div className="text-[10px] text-zinc-400">LEGAL HARBOR</div>
              <div className="text-cyan-400 font-bold">ETDA & PDPA</div>
            </div>
          </div>

          {/* Live Status Message Log */}
          <div className="p-3 rounded-xl bg-[#070a12] border border-cyan-500/30 text-center">
            <p className="text-xs text-cyan-300 font-mono tracking-wide font-bold">
              {progress < 100 ? (
                <>⚡ {phaseText} ({progress}%)</>
              ) : (
                <span className="text-emerald-400">👑 OMEGA INFINITY LOCKED — RUNTIME VERIFIED 100% GREEN</span>
              )}
            </p>
          </div>

          {/* Actions */}
          {onCancel && progress < 100 && (
            <div className="flex justify-end pt-2">
              <button
                onClick={() => {
                  playTone(400, 0.05);
                  onCancel();
                }}
                className="px-4 py-1.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 text-zinc-400 hover:text-white text-xs cursor-pointer"
              >
                ABORT INGRESS
              </button>
            </div>
          )}
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
};
