import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { Play, Pause, RotateCcw, Eye, Shield, Activity, Layers, Cpu } from 'lucide-react';

export interface Sovereign3DControlPlaneProps {
  blockHeight?: number;
  systemStatus?: string;
  onNodeSelect?: (nodeId: number) => void;
}

/**
 * ZYRQUEN Ω∞ Sovereign Kernel v4.16 (v1.2 LTS)
 * 3D Holographic Spatial Control Plane (WebGL Three.js Engine).
 * Renders Golden Icosahedron (Omega Core), Cyan Torus Warp Ring,
 * and 10 Orbiting Deca-Key Custodian Nodes in real-time 60 FPS WebGL canvas.
 */
export const Sovereign3DControlPlane: React.FC<Sovereign3DControlPlaneProps> = ({
  blockHeight = 849202,
  systemStatus = 'LOCKED_FROZEN_v1.2_LTS',
  onNodeSelect,
}) => {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const onNodeSelectRef = useRef(onNodeSelect);
  const [isRotating, setIsRotating] = useState<boolean>(true);
  const [selectedNode, setSelectedNode] = useState<number | null>(null);
  const [fps, setFps] = useState<number>(60);
  const [showWireframe, setShowWireframe] = useState<boolean>(true);

  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const animationFrameRef = useRef<number | null>(null);
  const nodeMeshesRef = useRef<THREE.Mesh[]>([]);

  useEffect(() => {
    onNodeSelectRef.current = onNodeSelect;
  }, [onNodeSelect]);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const width = container.clientWidth;
    const height = container.clientHeight || 450;

    // 1. Scene & Camera Setup
    const scene = new THREE.Scene();
    sceneRef.current = scene;
    scene.fog = new THREE.FogExp2(0x09090b, 0.035);

    const camera = new THREE.PerspectiveCamera(60, width / height, 0.1, 1000);
    camera.position.set(0, 3, 9);
    camera.lookAt(0, 0, 0);
    cameraRef.current = camera;

    // 2. WebGL Renderer
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.setClearColor(0x09090b, 1);
    rendererRef.current = renderer;

    container.appendChild(renderer.domElement);

    // 3. Lighting Setup
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.6);
    scene.add(ambientLight);

    const goldPointLight = new THREE.PointLight(0xffd700, 2.5, 20);
    goldPointLight.position.set(0, 0, 0);
    scene.add(goldPointLight);

    const cyanPointLight = new THREE.PointLight(0x00f3ff, 2.0, 25);
    cyanPointLight.position.set(5, 5, 5);
    scene.add(cyanPointLight);

    // 4. Core Object 1: Golden Icosahedron (Omega Core)
    const omegaCoreGroup = new THREE.Group();
    scene.add(omegaCoreGroup);

    const icoGeo = new THREE.IcosahedronGeometry(1.4, 0);
    const icoMat = new THREE.MeshPhongMaterial({
      color: 0xffd700,
      emissive: 0x8b6508,
      wireframe: showWireframe,
      shininess: 100,
    });
    const omegaCore = new THREE.Mesh(icoGeo, icoMat);
    omegaCoreGroup.add(omegaCore);

    // Inner glowing core
    const innerGeo = new THREE.IcosahedronGeometry(0.8, 1);
    const innerMat = new THREE.MeshBasicMaterial({
      color: 0xffaa00,
      wireframe: true,
      transparent: true,
      opacity: 0.6,
    });
    const innerCore = new THREE.Mesh(innerGeo, innerMat);
    omegaCoreGroup.add(innerCore);

    // 5. Core Object 2: Cyan Torus Warp Ring
    const torusGeo = new THREE.TorusGeometry(2.8, 0.08, 16, 100);
    const torusMat = new THREE.MeshStandardMaterial({
      color: 0x00f3ff,
      emissive: 0x0088aa,
      roughness: 0.2,
      metalness: 0.8,
    });
    const cyanTorus = new THREE.Mesh(torusGeo, torusMat);
    cyanTorus.rotation.x = Math.PI / 3;
    scene.add(cyanTorus);

    // Outer secondary ring
    const torus2Geo = new THREE.TorusGeometry(3.6, 0.03, 12, 80);
    const torus2Mat = new THREE.MeshBasicMaterial({
      color: 0xa855f7,
      wireframe: true,
      transparent: true,
      opacity: 0.5,
    });
    const outerTorus = new THREE.Mesh(torus2Geo, torus2Mat);
    outerTorus.rotation.x = -Math.PI / 4;
    scene.add(outerTorus);

    // 6. Core Object 3: 10 Orbiting Deca-Key Custodian Nodes
    const nodeGroup = new THREE.Group();
    scene.add(nodeGroup);

    const nodeMeshes: THREE.Mesh[] = [];
    const nodeCount = 10;
    const orbitRadius = 4.2;

    for (let i = 0; i < nodeCount; i++) {
      const angle = (i / nodeCount) * Math.PI * 2;
      const x = Math.cos(angle) * orbitRadius;
      const z = Math.sin(angle) * orbitRadius;

      const nodeGeo = new THREE.OctahedronGeometry(0.28, 0);
      const nodeMat = new THREE.MeshStandardMaterial({
        color: 0x00ff66,
        emissive: 0x006622,
        roughness: 0.3,
      });
      const nodeMesh = new THREE.Mesh(nodeGeo, nodeMat);
      nodeMesh.position.set(x, 0, z);
      nodeMesh.userData = { nodeId: i, label: `HSM Custodian Node #${i + 1}`, angle };

      nodeGroup.add(nodeMesh);
      nodeMeshes.push(nodeMesh);

      // Connective beam to core
      const lineGeo = new THREE.BufferGeometry().setFromPoints([
        new THREE.Vector3(0, 0, 0),
        new THREE.Vector3(x, 0, z),
      ]);
      const lineMat = new THREE.LineDashedMaterial({
        color: 0x00ff66,
        dashSize: 0.2,
        gapSize: 0.1,
        transparent: true,
        opacity: 0.3,
      });
      const line = new THREE.Line(lineGeo, lineMat);
      line.computeLineDistances();
      nodeGroup.add(line);
    }
    nodeMeshesRef.current = nodeMeshes;

    // 7. Background Starfield Particle Grid
    const particleCount = 400;
    const particleGeo = new THREE.BufferGeometry();
    const particleCoords = new Float32Array(particleCount * 3);

    for (let i = 0; i < particleCount * 3; i++) {
      particleCoords[i] = (Math.random() - 0.5) * 30;
    }

    particleGeo.setAttribute('position', new THREE.BufferAttribute(particleCoords, 3));
    const particleMat = new THREE.PointsMaterial({
      size: 0.05,
      color: 0x3f3f46,
      transparent: true,
      opacity: 0.8,
    });
    const starfield = new THREE.Points(particleGeo, particleMat);
    scene.add(starfield);

    // 8. Raycaster Pointer Interaction for Node Selection
    const raycaster = new THREE.Raycaster();
    const pointer = new THREE.Vector2();

    const handlePointerDown = (event: PointerEvent) => {
      const bounds = renderer.domElement.getBoundingClientRect();
      pointer.x = ((event.clientX - bounds.left) / bounds.width) * 2 - 1;
      pointer.y = -((event.clientY - bounds.top) / bounds.height) * 2 + 1;

      raycaster.setFromCamera(pointer, camera);
      const intersects = raycaster.intersectObjects(nodeMeshes);
      if (intersects.length > 0) {
        const obj = intersects[0].object as THREE.Mesh;
        if (typeof obj.userData.nodeId === 'number') {
          const id = obj.userData.nodeId;
          setSelectedNode(id);
          onNodeSelectRef.current?.(id);
        }
      }
    };
    renderer.domElement.addEventListener('pointerdown', handlePointerDown);

    // 9. Animation Loop
    let lastTime = performance.now();
    let frameCount = 0;

    const animate = (time: number) => {
      animationFrameRef.current = requestAnimationFrame(animate);

      // FPS counter
      frameCount++;
      if (time - lastTime >= 1000) {
        setFps(frameCount);
        frameCount = 0;
        lastTime = time;
      }

      if (isRotating) {
        omegaCoreGroup.rotation.y += 0.01;
        omegaCoreGroup.rotation.x += 0.005;
        cyanTorus.rotation.z += 0.008;
        outerTorus.rotation.z -= 0.004;
        nodeGroup.rotation.y += 0.006;

        nodeMeshes.forEach((mesh) => {
          mesh.rotation.x += 0.02;
          mesh.rotation.y += 0.02;
        });
      }

      renderer.render(scene, camera);
    };

    animate(performance.now());

    // 10. Resize Listener
    const handleResize = () => {
      if (!containerRef.current) return;
      const newWidth = containerRef.current.clientWidth;
      const newHeight = containerRef.current.clientHeight || 450;

      camera.aspect = newWidth / newHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(newWidth, newHeight);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      renderer.domElement.removeEventListener('pointerdown', handlePointerDown);
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
      if (containerRef.current && renderer.domElement && containerRef.current.contains(renderer.domElement)) {
        containerRef.current.removeChild(renderer.domElement);
      }
      icoGeo.dispose();
      icoMat.dispose();
      innerGeo.dispose();
      innerMat.dispose();
      torusGeo.dispose();
      torusMat.dispose();
      torus2Geo.dispose();
      torus2Mat.dispose();
      particleGeo.dispose();
      particleMat.dispose();
      renderer.dispose();
    };
  }, [isRotating, showWireframe]);

  const handleResetCamera = () => {
    if (cameraRef.current) {
      cameraRef.current.position.set(0, 3, 9);
      cameraRef.current.lookAt(0, 0, 0);
    }
  };

  return (
    <div className="w-full bg-zinc-950 border border-zinc-800 rounded-2xl overflow-hidden font-mono shadow-2xl relative">
      {/* Overlay Header */}
      <div className="absolute top-0 left-0 right-0 z-10 p-4 bg-gradient-to-b from-zinc-950/90 to-transparent flex flex-wrap items-center justify-between gap-3 pointer-events-none">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-xl bg-amber-950/60 border border-amber-800/50 text-amber-400">
            <Cpu className="w-5 h-5 animate-pulse" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-zinc-100 flex items-center gap-2">
              <span>3D Holographic Spatial Control Plane</span>
              <span className="text-[10px] px-1.5 py-0.5 rounded bg-cyan-950 border border-cyan-800 text-cyan-400">
                WebGL 60 FPS
              </span>
            </h2>
            <p className="text-[11px] text-zinc-400">
              Omega Core (Golden Icosahedron) • 10 Deca-Key Custodians
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 pointer-events-auto">
          <button
            type="button"
            onClick={() => setShowWireframe(!showWireframe)}
            className="px-2.5 py-1.5 rounded-lg bg-zinc-900/80 border border-zinc-700/80 text-zinc-300 hover:text-white text-xs flex items-center gap-1.5 transition cursor-pointer"
            title="Toggle Wireframe"
          >
            <Layers className="w-3.5 h-3.5 text-cyan-400" />
            <span className="hidden sm:inline">{showWireframe ? 'Wireframe' : 'Solid'}</span>
          </button>

          <button
            type="button"
            onClick={handleResetCamera}
            className="p-1.5 rounded-lg bg-zinc-900/80 border border-zinc-700/80 text-zinc-300 hover:text-white text-xs transition cursor-pointer"
            title="Reset Camera Orientation"
          >
            <RotateCcw className="w-3.5 h-3.5 text-slate-400" />
          </button>

          <button
            type="button"
            onClick={() => setIsRotating(!isRotating)}
            className="px-3 py-1.5 rounded-lg bg-zinc-900/80 border border-zinc-700/80 text-zinc-300 hover:text-white text-xs flex items-center gap-1.5 transition cursor-pointer"
          >
            {isRotating ? <Pause className="w-3.5 h-3.5 text-amber-400" /> : <Play className="w-3.5 h-3.5 text-emerald-400" />}
            <span>{isRotating ? 'Pause' : 'Resume'}</span>
          </button>
        </div>
      </div>

      {/* 3D WebGL Canvas Container */}
      <div ref={containerRef} className="w-full h-[450px] cursor-grab active:cursor-grabbing relative" />

      {/* Selected Node Notification Banner */}
      {selectedNode !== null && (
        <div className="absolute bottom-14 left-4 right-4 z-10 bg-slate-900/90 border border-cyan-500/50 p-2.5 rounded-xl shadow-lg flex items-center justify-between text-xs font-mono">
          <div className="flex items-center gap-2">
            <Eye className="w-4 h-4 text-cyan-400" />
            <span className="text-zinc-300 font-bold">Selected Custodian Node #{selectedNode + 1}</span>
            <span className="text-emerald-400 text-[10px]">(FIPS 140-3 Level 4 HSM Active)</span>
          </div>
          <button
            type="button"
            onClick={() => setSelectedNode(null)}
            className="text-zinc-500 hover:text-white text-[11px] cursor-pointer"
          >
            Deselect
          </button>
        </div>
      )}

      {/* Overlay Footer Bar */}
      <div className="p-3 bg-zinc-900/90 border-t border-zinc-800 flex flex-wrap items-center justify-between gap-3 text-xs text-zinc-400">
        <div className="flex items-center gap-4">
          <span className="flex items-center gap-1 text-emerald-400 font-bold">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
            <span>FPS: {fps}</span>
          </span>
          <span>Block #{blockHeight}</span>
          <span className="text-cyan-400">Status: {systemStatus}</span>
        </div>

        <div className="flex items-center gap-2 font-bold">
          <span className="text-[11px] text-zinc-400">10/10 REAL_HSM Quorum Active</span>
          <Shield className="w-4 h-4 text-emerald-400" />
        </div>
      </div>
    </div>
  );
};

export default Sovereign3DControlPlane;
