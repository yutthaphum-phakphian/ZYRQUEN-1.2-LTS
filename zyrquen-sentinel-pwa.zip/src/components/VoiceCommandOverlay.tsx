import React, { useState, useEffect } from 'react';
import {
  Mic,
  MicOff,
  AlertTriangle,
  ShieldAlert,
  CheckCircle2,
  XCircle,
  Sparkles,
  Lock,
  Zap,
  Volume2,
  ChevronRight,
  Terminal,
  Activity,
  Compass,
  Camera,
  Play,
  RotateCcw,
  Sliders,
  Radio,
  Languages,
} from 'lucide-react';
import { useVoiceCommand, PendingVoiceCommand } from '../hooks/useVoiceCommand';
import { ViewType } from '../types';
import { SystemEvent } from './SystemEventsSidebar';
import { playTone } from './AudioSynthesizer';

interface VoiceCommandOverlayProps {
  onNavigate: (view: ViewType) => void;
  onCaptureSnapshot: () => void;
  onNotifyEvent: (type: SystemEvent['type'], title: string, desc: string, meta?: string, sev?: SystemEvent['severity']) => void;
  inline?: boolean;
  className?: string;
}

export const VoiceCommandOverlay: React.FC<VoiceCommandOverlayProps> = ({ 
  onNavigate, 
  onCaptureSnapshot, 
  onNotifyEvent,
  inline = false,
  className = '',
}) => {
  const {
    isListening,
    realTimeTranscript,
    lastCommand,
    toggleListening,
    pendingCommand,
    confirmPendingCommand,
    cancelPendingCommand,
    simulateVoiceCommand,
    requireManualConfirmAll,
    setRequireManualConfirmAll,
    speechLanguage,
    setSpeechLanguage,
  } = useVoiceCommand(onNavigate, onCaptureSnapshot, onNotifyEvent);

  const [showTestMenu, setShowTestMenu] = useState<boolean>(false);
  const [customPhrase, setCustomPhrase] = useState<string>('');
  const [countdown, setCountdown] = useState<number>(10);
  const [totalSeconds, setTotalSeconds] = useState<number>(10);

  // Auto-countdown & execution logic
  useEffect(() => {
    if (!pendingCommand) {
      setCountdown(0);
      return;
    }

    const duration = pendingCommand.timeoutSeconds || 5;
    setTotalSeconds(duration);
    setCountdown(duration);

    const timer = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          // If the command allows auto-execution and user hasn't toggled manual confirm all
          if (!pendingCommand.requiresManualConfirmation) {
            confirmPendingCommand();
          } else {
            // For critical commands, timer expiring aborts for security
            cancelPendingCommand();
          }
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [pendingCommand, confirmPendingCommand, cancelPendingCommand]);

  const testPresets: Array<{ label: string; phrase: string; icon: any; color: string; isCritical?: boolean }> = [
    { label: 'Ledger (บัญชีแยกประเภท)', phrase: 'Switch to ledger view', icon: Compass, color: 'text-emerald-400' },
    { label: 'Quantum (ห้องควอนตัม)', phrase: 'Switch to quantum enclave', icon: Activity, color: 'text-cyan-400' },
    { label: 'Capture Snapshot (ถ่ายภาพสแนปช็อต)', phrase: 'Capture hardware snapshot', icon: Camera, color: 'text-blue-400' },
    { label: 'คำสั่งไทย: ไปที่แดชบอร์ด', phrase: 'ไปที่แดชบอร์ด', icon: Compass, color: 'text-emerald-400' },
    { label: 'คำสั่งไทย: ถ่ายภาพสแนปช็อต', phrase: 'ถ่ายภาพสแนปช็อต', icon: Camera, color: 'text-blue-400' },
    { label: 'Freeze State (ตรึงสถานะ)', phrase: 'Freeze sovereign state', icon: Lock, color: 'text-amber-400', isCritical: true },
    { label: 'คำสั่งไทย: ตรึงสถานะระบบ', phrase: 'ตรึงสถานะ', icon: Lock, color: 'text-amber-400', isCritical: true },
    { label: 'Quantum Zeroize (ทำลายคีย์)', phrase: 'Quantum zeroize keys', icon: Zap, color: 'text-red-400', isCritical: true },
    { label: 'Quarantine Chamber (กักกันห้อง 02)', phrase: 'Emergency quarantine chamber 02', icon: ShieldAlert, color: 'text-amber-400', isCritical: true },
    { label: 'Phoenix Protocol (กู้คืนควอรัม)', phrase: 'Reconstitute quorum phoenix protocol', icon: Sparkles, color: 'text-emerald-400', isCritical: true },
    { label: 'Sovereign Seal (ประทับตราอธิปไตย)', phrase: 'Execute master sovereign seal', icon: CheckCircle2, color: 'text-cyan-400', isCritical: true },
    { label: 'Court Dossier (ส่งออกเอกสารศาล)', phrase: 'Export court dossier pdf', icon: Terminal, color: 'text-violet-400', isCritical: true },
  ];

  const controls = (
    <div className="flex items-center gap-2 relative font-mono">
      {/* Real-Time Live Voice Streaming HUD Pill */}
      {isListening && (
        <div className="bg-[#050814]/95 border border-cyan-500/50 text-cyan-300 px-3 py-1.5 rounded-xl shadow-[0_0_25px_rgba(6,182,212,0.35)] text-xs flex items-center gap-2.5 backdrop-blur-xl animate-in fade-in slide-in-from-right-3 shrink-0">
          {/* Audio Equalizer Bars Animation */}
          <div className="flex items-center gap-0.5 h-3.5">
            <span className="w-0.5 bg-cyan-400 rounded-full animate-[pulse_0.4s_ease-in-out_infinite] h-3" />
            <span className="w-0.5 bg-emerald-400 rounded-full animate-[pulse_0.6s_ease-in-out_infinite] h-2" />
            <span className="w-0.5 bg-cyan-300 rounded-full animate-[pulse_0.3s_ease-in-out_infinite] h-3.5" />
            <span className="w-0.5 bg-cyan-500 rounded-full animate-[pulse_0.5s_ease-in-out_infinite] h-1.5" />
          </div>

          <div className="flex items-center gap-1.5">
            <span className="text-[10px] uppercase font-bold text-emerald-400 bg-emerald-500/20 px-1.5 py-0.5 rounded flex items-center gap-1">
              <span>LIVE</span>
              <span className="text-[9px] opacity-75 font-mono">[{speechLanguage === 'th-TH' ? 'TH' : 'EN'}]</span>
            </span>
            <span className="max-w-[200px] truncate text-white">
              {realTimeTranscript ? (
                <span className="text-cyan-200">
                  &ldquo;{realTimeTranscript}&rdquo;<span className="animate-ping">|</span>
                </span>
              ) : (
                <span className="text-zinc-400 italic">
                  {speechLanguage === 'th-TH' ? 'กำลังฟังคำสั่งเสียง...' : 'Listening for directives...'}
                </span>
              )}
            </span>
          </div>
        </div>
      )}

      {/* Main Microphone Toggle Button */}
      <button
        onClick={toggleListening}
        className={`h-10 w-10 rounded-xl border transition-all shadow-xl backdrop-blur-xl flex items-center justify-center cursor-pointer shrink-0 ${
          isListening 
            ? 'bg-cyan-500/20 border-cyan-400 text-cyan-300 shadow-[0_0_30px_rgba(6,182,212,0.4)] animate-pulse'
            : 'bg-slate-900/90 border-slate-700 hover:border-cyan-500/60 text-slate-300 hover:text-cyan-400'
        }`}
        title={isListening ? 'ไมโครโฟนทำงานอยู่ • กดเพื่อหยุด' : 'เปิดระบบคำสั่งเสียง • พูดคำสั่งผ่านไมโครโฟน'}
      >
        {isListening ? <Mic className="w-4 h-4 text-cyan-400" /> : <MicOff className="w-4 h-4 text-slate-400" />}
      </button>

      {/* Test / Simulate Voice Command Dropdown Button */}
      <button
        onClick={() => {
          playTone(600, 0.02);
          setShowTestMenu(!showTestMenu);
        }}
        className="h-10 px-2.5 rounded-xl bg-slate-900/90 hover:bg-slate-800 border border-slate-700 hover:border-cyan-500/50 text-[11px] font-mono text-cyan-300 transition-all shadow-md flex items-center gap-1.5 cursor-pointer shrink-0"
        title="ทดสอบและจำลองคำสั่งเสียง (Voice Test)"
      >
        <Radio className="w-3.5 h-3.5 text-cyan-400" />
        <span className="hidden sm:inline">Voice Test</span>
      </button>

      {/* Quick Test Menu Popover */}
      {showTestMenu && (
        <div className="absolute bottom-12 right-0 w-84 p-4 rounded-2xl bg-[#090d1c]/95 border border-cyan-500/40 shadow-2xl backdrop-blur-2xl font-mono text-xs z-50 animate-in fade-in slide-in-from-bottom-2 space-y-3">
          <div className="flex items-center justify-between border-b border-white/10 pb-2">
            <span className="font-bold text-white flex items-center gap-1.5 text-xs">
              <Volume2 className="w-4 h-4 text-cyan-400" />
              Voice Recognition Simulator
            </span>
            <button
              onClick={() => setShowTestMenu(false)}
              className="text-zinc-500 hover:text-zinc-300 text-xs px-1"
            >
              ✕
            </button>
          </div>

          {/* Language Toggle */}
          <div className="flex items-center justify-between p-2 rounded-xl bg-white/5 border border-white/10 text-[11px]">
            <span className="text-zinc-300 flex items-center gap-1.5">
              <Languages className="w-3.5 h-3.5 text-cyan-400" />
              ภาษาการรู้จำเสียง:
            </span>
            <div className="flex items-center gap-1 bg-black/40 p-1 rounded-lg border border-white/10">
              <button
                onClick={() => setSpeechLanguage('th-TH')}
                className={`px-2 py-0.5 rounded text-[10px] font-bold transition-all ${
                  speechLanguage === 'th-TH' ? 'bg-cyan-500 text-black' : 'text-zinc-400 hover:text-white'
                }`}
              >
                ไทย (TH)
              </button>
              <button
                onClick={() => setSpeechLanguage('en-US')}
                className={`px-2 py-0.5 rounded text-[10px] font-bold transition-all ${
                  speechLanguage === 'en-US' ? 'bg-cyan-500 text-black' : 'text-zinc-400 hover:text-white'
                }`}
              >
                English (EN)
              </button>
            </div>
          </div>

          {/* Custom Phrase Simulator */}
          <div className="space-y-1.5">
            <label className="text-[10px] text-zinc-400 block font-bold uppercase tracking-wider">
              Simulate Real-Time Speech Stream:
            </label>
            <div className="flex gap-1.5">
              <input
                type="text"
                value={customPhrase}
                onChange={(e) => setCustomPhrase(e.target.value)}
                placeholder="เช่น ไปที่แดชบอร์ด, Freeze state"
                className="flex-1 px-2.5 py-1.5 rounded-lg bg-black/60 border border-zinc-700 text-cyan-200 text-xs focus:outline-none focus:border-cyan-400"
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && customPhrase.trim()) {
                    simulateVoiceCommand(customPhrase.trim(), true);
                    setShowTestMenu(false);
                  }
                }}
              />
              <button
                onClick={() => {
                  if (customPhrase.trim()) {
                    simulateVoiceCommand(customPhrase.trim(), true);
                    setShowTestMenu(false);
                  }
                }}
                className="px-2.5 py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold transition-all cursor-pointer flex items-center gap-1"
                title="จำลองเสียงแบบสตรีมมิ่ง"
              >
                <Play className="w-3 h-3" />
                <span>Stream</span>
              </button>
            </div>
          </div>

          {/* Strict Verification Toggle */}
          <div className="p-2 rounded-xl bg-white/5 border border-white/10 flex items-center justify-between text-[10px]">
            <span className="text-zinc-300">บังคับกดยืนยันด้วยตนเองทุกคำสั่ง:</span>
            <input
              type="checkbox"
              checked={requireManualConfirmAll}
              onChange={(e) => setRequireManualConfirmAll(e.target.checked)}
              className="rounded accent-cyan-500 cursor-pointer"
            />
          </div>

          {/* Preset Commands */}
          <div className="space-y-1 max-h-56 overflow-y-auto pr-1">
            <span className="text-[10px] text-zinc-400 block font-bold uppercase tracking-wider mb-1">
              Select Preset to Verify:
            </span>
            {testPresets.map((tc) => {
              const Icon = tc.icon;
              return (
                <button
                  key={tc.label}
                  onClick={() => {
                    playTone(680, 0.03);
                    simulateVoiceCommand(tc.phrase, true);
                    setShowTestMenu(false);
                  }}
                  className="w-full text-left p-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/5 hover:border-cyan-500/30 flex items-center justify-between text-[11px] text-zinc-300 hover:text-white transition-all cursor-pointer"
                >
                  <div className="flex items-center gap-2">
                    <Icon className={`w-3.5 h-3.5 ${tc.color}`} />
                    <span>{tc.label}</span>
                  </div>
                  {tc.isCritical && (
                    <span className="text-[9px] px-1 py-0.2 rounded bg-amber-500/20 text-amber-300 font-bold">
                      CRITICAL
                    </span>
                  )}
                  <ChevronRight className="w-3 h-3 text-zinc-500" />
                </button>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );

  return (
    <>
      {/* Inline or Floating Voice Controls */}
      {inline ? (
        <div className={`flex items-center gap-2 ${className}`}>
          {controls}
        </div>
      ) : (
        <div className={`fixed bottom-3 sm:bottom-4 right-24 sm:right-48 z-40 flex items-center gap-2 ${className}`}>
          {controls}
        </div>
      )}

      {/* VISUAL CONFIRMATION FEEDBACK UI (REAL-TIME RECOGNIZED TEXT & PRE-EXECUTION VERIFICATION) */}
      {pendingCommand && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200 font-sans">
          <div className={`relative w-full max-w-xl p-6 sm:p-7 rounded-[32px] bg-gradient-to-br from-[#0b0e1e] via-[#080b17] to-[#04060d] border shadow-2xl space-y-5 text-white font-mono animate-in zoom-in-95 duration-200 ${
            pendingCommand.severity === 'CRITICAL'
              ? 'border-red-500/70 shadow-[0_0_90px_rgba(239,68,68,0.25)]'
              : pendingCommand.severity === 'HIGH'
              ? 'border-amber-500/70 shadow-[0_0_80px_rgba(245,158,11,0.25)]'
              : 'border-cyan-500/70 shadow-[0_0_70px_rgba(6,182,212,0.25)]'
          }`}>
            
            {/* Modal Header Badge Bar */}
            <div className="flex items-start justify-between gap-3 border-b border-white/10 pb-4">
              <div className="flex items-center gap-3">
                <div className={`p-3 rounded-2xl border shadow-lg ${
                  pendingCommand.severity === 'CRITICAL'
                    ? 'bg-red-500/20 text-red-400 border-red-500/40 shadow-[0_0_20px_rgba(239,68,68,0.3)] animate-pulse'
                    : pendingCommand.severity === 'HIGH'
                    ? 'bg-amber-500/20 text-amber-300 border-amber-500/40 shadow-[0_0_20px_rgba(245,158,11,0.3)] animate-pulse'
                    : 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40 shadow-[0_0_20px_rgba(6,182,212,0.3)]'
                }`}>
                  {pendingCommand.severity === 'CRITICAL' ? (
                    <ShieldAlert className="w-6 h-6" />
                  ) : pendingCommand.severity === 'HIGH' ? (
                    <AlertTriangle className="w-6 h-6" />
                  ) : (
                    <Activity className="w-6 h-6 text-cyan-400" />
                  )}
                </div>

                <div>
                  <div className="flex flex-wrap items-center gap-2">
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold border ${
                      pendingCommand.severity === 'CRITICAL'
                        ? 'bg-red-500/20 border-red-500/50 text-red-200'
                        : pendingCommand.severity === 'HIGH'
                        ? 'bg-amber-500/20 border-amber-500/50 text-amber-200'
                        : 'bg-cyan-500/20 border-cyan-500/50 text-cyan-200'
                    }`}>
                      {pendingCommand.category}
                    </span>

                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-white/10 border border-white/10 text-zinc-300">
                      {pendingCommand.severity === 'CRITICAL' || pendingCommand.severity === 'HIGH'
                        ? 'OMEGA-1 CLEARANCE REQUIRED'
                        : 'VERIFY DIRECTIVE (ยืนยันคำสั่ง)'}
                    </span>
                  </div>

                  <h3 className="text-base sm:text-lg font-bold text-white mt-1">
                    Voice Command Verification Stage (ขั้นตอนยืนยันคำสั่งเสียง)
                  </h3>
                </div>
              </div>

              {/* Countdown badge */}
              <div className="flex flex-col items-end shrink-0">
                <span className="text-[10px] text-zinc-400 uppercase tracking-wider">
                  {pendingCommand.requiresManualConfirmation ? 'Security Timeout' : 'Auto-Exec In'}
                </span>
                <span className={`text-xl font-black font-mono ${
                  pendingCommand.severity === 'CRITICAL' ? 'text-red-400' : 'text-cyan-300'
                }`}>
                  {countdown}s
                </span>
              </div>
            </div>

            {/* REAL-TIME RECOGNIZED VOICE COMMAND TEXT CONTAINER */}
            <div className="p-4 rounded-2xl bg-[#04060e] border border-cyan-500/40 shadow-inner space-y-2 relative overflow-hidden">
              <div className="flex items-center justify-between">
                <div className="text-[10px] uppercase text-zinc-400 font-bold flex items-center gap-1.5">
                  <Mic className="w-3.5 h-3.5 text-cyan-400 animate-pulse" />
                  <span>Real-Time Recognized Voice Text (ข้อความเสียงที่ตรวจจับได้):</span>
                </div>
                <span className="px-2 py-0.5 rounded text-[9px] font-bold bg-cyan-500/15 text-cyan-300 border border-cyan-500/30">
                  Confidence: 99.8%
                </span>
              </div>

              {/* Spoken Text Highlight */}
              <div className="text-base sm:text-xl font-bold text-cyan-200 tracking-wide break-words pl-4 border-l-4 border-cyan-400 py-1.5 bg-cyan-950/25 rounded-r-xl font-mono shadow-sm">
                &ldquo;{pendingCommand.transcript}&rdquo;
              </div>

              <div className="text-[10px] text-zinc-400 flex items-center gap-1.5 pt-0.5">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                <span>คำสั่งได้รับการตรวจสอบกับสารบบความปลอดภัย โปรดยืนยันการสั่งการเพื่อเริ่มทำงาน</span>
              </div>
            </div>

            {/* Target Action & Subsystem Forensic Metadata */}
            <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-2.5 text-xs">
              <div className="flex items-center justify-between">
                <span className="text-zinc-400">การทำงานเป้าหมาย (Target Action):</span>
                <strong className="text-white text-right">{pendingCommand.title}</strong>
              </div>

              <div className="flex items-center justify-between">
                <span className="text-zinc-400">ระบบปลายทาง (Target Subsystem):</span>
                <strong className="text-cyan-300 text-right">{pendingCommand.subsystem}</strong>
              </div>

              {pendingCommand.description && (
                <div className="border-t border-white/5 pt-2">
                  <span className="text-zinc-400 block mb-0.5">รายละเอียดคำสั่ง:</span>
                  <p className="text-[11px] text-zinc-300 leading-relaxed font-sans">
                    {pendingCommand.description}
                  </p>
                </div>
              )}

              {pendingCommand.impact && (
                <div className="border-t border-white/5 pt-2">
                  <span className="text-amber-400/90 block mb-0.5 font-bold">ขอบเขตผลกระทบ (Forensic Blast Radius):</span>
                  <p className="text-[11px] text-amber-200/80 leading-relaxed font-sans">
                    {pendingCommand.impact}
                  </p>
                </div>
              )}
            </div>

            {/* Animated Verification Countdown Progress Bar */}
            <div className="space-y-1">
              <div className="flex items-center justify-between text-[10px] text-zinc-400">
                <span>หน้าต่างเวลายืนยัน (Verification Window)</span>
                <span>{countdown} / {totalSeconds}s</span>
              </div>
              <div className="w-full h-1.5 bg-zinc-800 rounded-full overflow-hidden">
                <div
                  className={`h-full transition-all duration-1000 ease-linear rounded-full ${
                    pendingCommand.severity === 'CRITICAL'
                      ? 'bg-red-500'
                      : pendingCommand.severity === 'HIGH'
                      ? 'bg-amber-400'
                      : 'bg-cyan-400'
                  }`}
                  style={{ width: `${Math.max(0, (countdown / totalSeconds) * 100)}%` }}
                />
              </div>
            </div>

            {/* Action Buttons: Confirm & Execute vs. Cancel / Abort */}
            <div className="grid grid-cols-2 gap-3 pt-1">
              <button
                onClick={cancelPendingCommand}
                className="px-4 py-3 rounded-2xl bg-zinc-800/80 hover:bg-zinc-700/90 border border-zinc-600 text-zinc-200 hover:text-white font-mono text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer shadow-lg"
              >
                <XCircle className="w-4 h-4 text-zinc-400" />
                <span>ยกเลิก (Cancel)</span>
              </button>

              <button
                onClick={confirmPendingCommand}
                className={`px-4 py-3 rounded-2xl text-white font-mono text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer shadow-xl ${
                  pendingCommand.severity === 'CRITICAL'
                    ? 'bg-gradient-to-r from-red-600 via-rose-600 to-red-600 hover:from-red-500 hover:to-rose-500 border border-red-400 shadow-[0_0_25px_rgba(239,68,68,0.4)]'
                    : 'bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-600 hover:from-emerald-500 hover:to-teal-500 border border-emerald-400 shadow-[0_0_25px_rgba(16,185,129,0.35)]'
                }`}
              >
                <CheckCircle2 className="w-4 h-4 text-white" />
                <span>ยืนยันคำสั่ง (Execute)</span>
              </button>
            </div>

            {/* Spoken Voice Confirmation Hint */}
            <div className="text-center text-[10px] text-zinc-400 font-mono">
              ระบบยืนยันด้วยเสียง: พูดว่า <strong className="text-emerald-400">&ldquo;ยืนยัน&rdquo;</strong> หรือ <strong className="text-emerald-400">&ldquo;Confirm&rdquo;</strong> เพื่อสั่งทำงาน • พูดว่า <strong className="text-zinc-300">&ldquo;ยกเลิก&rdquo;</strong> หรือ <strong className="text-zinc-300">&ldquo;Cancel&rdquo;</strong> เพื่อยกเลิก
            </div>
          </div>
        </div>
      )}
    </>
  );
};
