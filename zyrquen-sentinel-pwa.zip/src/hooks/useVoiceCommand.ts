import { useEffect, useState, useCallback, useRef } from 'react';
import { ViewType } from '../types';
import { SystemEvent } from '../components/SystemEventsSidebar';
import { playTone, playAuditChime } from '../components/AudioSynthesizer';

export type VoiceCommandCategory = 'NAVIGATION' | 'TELEMETRY' | 'SOVEREIGN_DIRECTIVE';
export type VoiceCommandSeverity = 'CRITICAL' | 'HIGH' | 'STANDARD';

export interface PendingVoiceCommand {
  id: string;
  transcript: string;
  category: VoiceCommandCategory;
  title: string;
  severity: VoiceCommandSeverity;
  description: string;
  subsystem: string;
  impact?: string;
  statutoryAnchor?: string;
  requiresManualConfirmation: boolean;
  timeoutSeconds: number;
  action: () => void;
}

// Backward compatibility alias for PendingSovereignCommand
export interface PendingSovereignCommand {
  id: string;
  transcript: string;
  commandType: 'FREEZE_STATE' | 'ZEROIZE_KEYS' | 'QUARANTINE_CHAMBER' | 'RECONSTITUTE_QUORUM' | 'SOVEREIGN_SEAL' | 'COURT_DOSSIER';
  title: string;
  severity: 'CRITICAL' | 'HIGH';
  description: string;
  impact: string;
  subsystem: string;
  action: () => void;
}

export const useVoiceCommand = (
  onNavigate: (view: ViewType) => void,
  onCaptureSnapshot: () => void,
  onNotifyEvent: (type: SystemEvent['type'], title: string, desc: string, meta?: string, sev?: SystemEvent['severity']) => void
) => {
  const [isListening, setIsListening] = useState(false);
  const [realTimeTranscript, setRealTimeTranscript] = useState<string>('');
  const [lastCommand, setLastCommand] = useState<string>('');
  const [pendingCommand, setPendingCommand] = useState<PendingVoiceCommand | null>(null);
  const [requireManualConfirmAll, setRequireManualConfirmAll] = useState<boolean>(false);
  const [speechLanguage, setSpeechLanguage] = useState<'th-TH' | 'en-US'>(() => {
    if (typeof navigator !== 'undefined' && navigator.language && navigator.language.toLowerCase().startsWith('th')) {
      return 'th-TH';
    }
    return 'en-US';
  });

  const pendingRef = useRef<PendingVoiceCommand | null>(null);
  pendingRef.current = pendingCommand;

  // Execute or confirm the pending action
  const confirmPendingCommand = useCallback(() => {
    if (pendingRef.current) {
      const cmd = pendingRef.current;
      playAuditChime();
      cmd.action();
      
      const eventSev: SystemEvent['severity'] = 
        cmd.severity === 'CRITICAL' ? 'critical' : cmd.severity === 'HIGH' ? 'warning' : 'info';

      onNotifyEvent(
        cmd.category === 'SOVEREIGN_DIRECTIVE' ? 'SECURITY' : 'AUDIO',
        `Command Verified & Executed: ${cmd.title}`,
        `Verified voice command: "${cmd.transcript}"`,
        `voice:${cmd.category.toLowerCase()}`,
        eventSev
      );
      setLastCommand(`Executed: "${cmd.transcript}"`);
      setRealTimeTranscript('');
      setPendingCommand(null);
    }
  }, [onNotifyEvent]);

  // Cancel or abort the pending action
  const cancelPendingCommand = useCallback(() => {
    if (pendingRef.current) {
      const cmd = pendingRef.current;
      playTone(330, 0.08);
      onNotifyEvent(
        'SECURITY',
        `Command Aborted: ${cmd.title}`,
        `User cancelled verification for: "${cmd.transcript}"`,
        'voice:abort',
        'info'
      );
      setLastCommand(`Cancelled: "${cmd.transcript}"`);
      setRealTimeTranscript('');
      setPendingCommand(null);
    }
  }, [onNotifyEvent]);

  // Core command processor used by both real SpeechRecognition and simulation
  const processTranscript = useCallback((rawTranscript: string) => {
    const transcript = rawTranscript.trim().toLowerCase();
    setLastCommand(rawTranscript);
    setRealTimeTranscript(rawTranscript);

    // If there is an active pending confirmation, check for confirmation or cancellation voice triggers (English + Thai)
    if (pendingRef.current) {
      if (
        transcript.includes('confirm') ||
        transcript.includes('execute') ||
        transcript.includes('proceed') ||
        transcript.includes('approve') ||
        transcript.includes('yes') ||
        transcript.includes('run') ||
        transcript.includes('ยืนยัน') ||
        transcript.includes('ดำเนินการ') ||
        transcript.includes('ตกลง') ||
        transcript.includes('ใช่') ||
        transcript.includes('ทำเลย') ||
        transcript.includes('เริ่ม')
      ) {
        confirmPendingCommand();
        return;
      }
      if (
        transcript.includes('cancel') ||
        transcript.includes('abort') ||
        transcript.includes('reject') ||
        transcript.includes('no') ||
        transcript.includes('stop') ||
        transcript.includes('ยกเลิก') ||
        transcript.includes('หยุด') ||
        transcript.includes('ไม่') ||
        transcript.includes('ปฏิเสธ')
      ) {
        cancelPendingCommand();
        return;
      }
    }

    // 1. High-Sensitivity Sovereign Command Detection (English + Thai)
    // Rule: Never auto-execute high-sensitivity directives; strictly display visual confirmation UI first!

    // A. Sovereign State Freeze / Immutable Lock
    if (
      transcript.includes('freeze') ||
      transcript.includes('immutable lock') ||
      transcript.includes('lock state') ||
      transcript.includes('write lock') ||
      transcript.includes('ตรึงสถานะ') ||
      transcript.includes('ล็อกระบบ') ||
      transcript.includes('ล็อกสถานะ')
    ) {
      playTone(880, 0.08);
      setPendingCommand({
        id: `cmd-freeze-${Date.now()}`,
        transcript: rawTranscript,
        category: 'SOVEREIGN_DIRECTIVE',
        title: 'Enforce Sovereign State Freeze (Zero-Mutation Lock)',
        severity: 'CRITICAL',
        description: 'Impose universal read-only write firewall across all 18 chambers (SSoT Mutation = 0, Δ0.00% Zero Drift).',
        impact: 'All state mutation RPCs will be rejected. System enters immutable audit mode.',
        subsystem: 'Chamber 00 / Genesis Truth Plane',
        statutoryAnchor: 'Thai ETDA B.E. 2544 Sections 9, 26, 28',
        requiresManualConfirmation: true,
        timeoutSeconds: 12,
        action: () => {
          onNavigate('ledger');
          onNotifyEvent('SECURITY', 'Sovereign State Write-Locked', 'Zero-mutation lock active across all 18 chambers.', 'voice:freeze', 'warning');
        }
      });
      return;
    }

    // B. Quantum Key Zeroization / Emergency Purge
    if (
      transcript.includes('zeroize') ||
      transcript.includes('quantum zeroize') ||
      transcript.includes('emergency purge') ||
      transcript.includes('purge keys') ||
      transcript.includes('ทำลายคีย์') ||
      transcript.includes('ล้างคีย์') ||
      transcript.includes('ซีโรไอซ์')
    ) {
      playTone(880, 0.08);
      setPendingCommand({
        id: `cmd-zeroize-${Date.now()}`,
        transcript: rawTranscript,
        category: 'SOVEREIGN_DIRECTIVE',
        title: 'Quantum Key Zeroization & Physical Tamper Quarantine',
        severity: 'CRITICAL',
        description: 'Instantly zeroize all ephemeral session keys and trigger FIPS 140-3 Level 4 hardware tamper barrier.',
        impact: 'Destroys ephemeral memory buffers. Re-authenticates via Sovereign Principal EP-SOVEREIGN-01.',
        subsystem: 'Chamber 01 / Quantum Key Distribution Enclave',
        statutoryAnchor: 'FIPS 140-3 Level 4 / PDPA Sec 37',
        requiresManualConfirmation: true,
        timeoutSeconds: 12,
        action: () => {
          onNavigate('security');
          onNotifyEvent('SECURITY', 'Zeroization Defense Triggered', 'Ephemeral session keys purged from memory under FIPS 140-3.', 'voice:zeroize', 'critical');
        }
      });
      return;
    }

    // C. Emergency Quarantine Chamber Isolation
    if (
      transcript.includes('quarantine') ||
      transcript.includes('isolate chamber') ||
      transcript.includes('lockdown chamber') ||
      transcript.includes('กักกันห้อง') ||
      transcript.includes('กักกัน') ||
      transcript.includes('ล็อกดาวน์')
    ) {
      playTone(820, 0.08);
      setPendingCommand({
        id: `cmd-quarantine-${Date.now()}`,
        transcript: rawTranscript,
        category: 'SOVEREIGN_DIRECTIVE',
        title: 'Emergency Quarantine Chamber 02 Fail-Closed Ring',
        severity: 'HIGH',
        description: 'Isolate anomalous node telemetry into Chamber 02 Quarantine Registry (#14,903–#14,907).',
        impact: 'Diverts incoming traffic to isolated cold-storage sandbox; prevents blast radius expansion.',
        subsystem: 'Chamber 02 / Fail-Closed Quarantine Ring',
        statutoryAnchor: 'Fail-Closed Quorum Invariant',
        requiresManualConfirmation: true,
        timeoutSeconds: 10,
        action: () => {
          onNavigate('ledger');
          onNotifyEvent('SECURITY', 'Chamber Quarantine Enforced', 'Anomalous blocks routed to Chamber 02 quarantine buffer.', 'voice:quarantine', 'warning');
        }
      });
      return;
    }

    // D. Reconstitute HSM Quorum / Phoenix Recovery Protocol
    if (
      transcript.includes('reconstitute') ||
      transcript.includes('phoenix') ||
      transcript.includes('recovery protocol') ||
      transcript.includes('quorum recover') ||
      transcript.includes('ฟีนิกซ์') ||
      transcript.includes('กู้คืนสภา') ||
      transcript.includes('กู้คืนควอรัม')
    ) {
      playTone(780, 0.08);
      setPendingCommand({
        id: `cmd-reconstitute-${Date.now()}`,
        transcript: rawTranscript,
        category: 'SOVEREIGN_DIRECTIVE',
        title: 'Reconstitute 10/10 REAL_HSM Quorum (Phoenix Protocol)',
        severity: 'HIGH',
        description: 'Engage crypto-agility switch to SPHINCS+ stateless fallback and re-establish 10/10 hardware quorum.',
        impact: 'Re-aligns BFT consensus nodes without ledger downtime (<3.20ms SLA).',
        subsystem: 'Chamber 04 / BFT Sovereign Consensus Engine',
        statutoryAnchor: '10/10 REAL_HSM Consensus Invariant',
        requiresManualConfirmation: true,
        timeoutSeconds: 10,
        action: () => {
          onNavigate('council');
          onNotifyEvent('SECURITY', 'Phoenix Recovery Protocol Executed', '10/10 REAL_HSM Quorum reconstituted successfully.', 'voice:phoenix', 'info');
        }
      });
      return;
    }

    // E. Cryptographic Sovereign Seal & Promotion
    if (
      transcript.includes('sovereign seal') ||
      transcript.includes('master seal') ||
      transcript.includes('promote block') ||
      transcript.includes('seal block') ||
      transcript.includes('ประทับตรา') ||
      transcript.includes('ซีลบล็อก') ||
      transcript.includes('ประทับตราอธิปไตย')
    ) {
      playTone(740, 0.08);
      setPendingCommand({
        id: `cmd-seal-${Date.now()}`,
        transcript: rawTranscript,
        category: 'SOVEREIGN_DIRECTIVE',
        title: 'Execute Master Sovereign Seal (Block #849,202)',
        severity: 'HIGH',
        description: 'Seal state with NIST FIPS 204 ML-DSA-87 signature and bind to Sovereign Principal EP-SOVEREIGN-01.',
        impact: 'Creates immutable court-admissible snapshot evidence packet.',
        subsystem: 'Chamber 16 / Sovereign Master Seal Engine',
        statutoryAnchor: 'Thai ETDA B.E. 2544 Section 26',
        requiresManualConfirmation: true,
        timeoutSeconds: 10,
        action: () => {
          onCaptureSnapshot();
          onNotifyEvent('FORENSIC', 'Master Sovereign Seal Committed', 'Block #849,202 sealed under NIST FIPS 204 ML-DSA-87.', 'voice:seal', 'success');
        }
      });
      return;
    }

    // F. Export Court-Ready Forensic Dossier
    if (
      transcript.includes('court dossier') ||
      transcript.includes('legal dossier') ||
      transcript.includes('export dossier') ||
      transcript.includes('export court') ||
      transcript.includes('เอกสารศาล') ||
      transcript.includes('สำนวนศาล') ||
      transcript.includes('ออกเอกสารศาล')
    ) {
      playTone(700, 0.06);
      setPendingCommand({
        id: `cmd-dossier-${Date.now()}`,
        transcript: rawTranscript,
        category: 'SOVEREIGN_DIRECTIVE',
        title: 'Generate Court-Admissible Legal Dossier (PDF)',
        severity: 'HIGH',
        description: 'Compile DOC-SOV-HSM-1010-2026-V9 evidence dossier with ETDA Sections 9, 26, 28 statutory bindings.',
        impact: 'Downloads court filing evidence packet with embedded QR codes and NIST PQC signatures.',
        subsystem: 'Chamber 17 / Legal & Statutory Attestation Enclave',
        statutoryAnchor: 'Thai ETDA B.E. 2544 Sections 9, 26, 28',
        requiresManualConfirmation: true,
        timeoutSeconds: 10,
        action: () => {
          window.location.href = '/legal/dossier-export';
          onNotifyEvent('COMPLIANCE', 'Court Dossier Generated', 'DOC-SOV-HSM-1010-2026-V9 exported for judicial proceedings.', 'voice:dossier', 'info');
        }
      });
      return;
    }

    // 2. Standard Commands: View Navigation across all ViewTypes (English + Thai)
    const commandMap: Record<string, { view: ViewType; label: string }> = {
      'dashboard': { view: 'dashboard', label: 'Dashboard Overview' },
      'แดชบอร์ด': { view: 'dashboard', label: 'แดชบอร์ดภาพรวมระบบ' },
      'หน้าหลัก': { view: 'dashboard', label: 'หน้าหลักระบบ' },

      'quantum': { view: 'quantum', label: 'Quantum Cryptography Enclave' },
      'ควอนตัม': { view: 'quantum', label: 'ห้องควอนตัมนิรภัย' },

      'nexus': { view: 'nexus', label: 'Infinity Nexus Portal' },
      'เน็กซัส': { view: 'nexus', label: 'เน็กซัส พอร์ทัล' },

      'vault': { view: 'vault', label: 'Cipher Vault Storage' },
      'วอลต์': { view: 'vault', label: 'คลังนิรภัยเข้ารหัส' },
      'คลังนิรภัย': { view: 'vault', label: 'คลังนิรภัยเข้ารหัส' },

      'ledger': { view: 'ledger', label: 'Immutable Audit Ledger & Merkle Root' },
      'บัญชีแยกประเภท': { view: 'ledger', label: 'บัญชีแยกประเภทที่ไม่สามารถแก้ไขได้' },
      'บล็อกเชน': { view: 'ledger', label: 'บัญชีแยกประเภท' },
      'เมอร์เคิล': { view: 'ledger', label: 'Merkle Tree Ledger' },

      'pulse': { view: 'pulse', label: 'Hardware Telemetry Pulse' },
      'พัลส์': { view: 'pulse', label: 'ชีพจรโทรมาตรฮาร์ดแวร์' },

      'forge': { view: 'forge', label: 'Deterministic Artifact Forge' },
      'ฟอร์จ': { view: 'forge', label: 'โรงหลอมหลักฐานดิจิทัล' },

      'matrix': { view: 'matrix', label: 'Evidence Truth Matrix' },
      'เมทริกซ์': { view: 'matrix', label: 'เมทริกซ์ความจริงของพยานหลักฐาน' },

      'archive': { view: 'archive', label: 'Cold-Storage Archive' },
      'คลังข้อมูล': { view: 'archive', label: 'คลังข้อมูลระยะยาว' },

      'console': { view: 'console', label: 'Macro Command Console' },
      'คอนโซล': { view: 'console', label: 'คอนโซลคำสั่งมาโคร' },

      'security': { view: 'security', label: 'Security & Penetration Test Suite' },
      'ความปลอดภัย': { view: 'security', label: 'ระบบความปลอดภัยและการทดสอบ' },

      'settings': { view: 'settings', label: 'System Configuration' },
      'ตั้งค่า': { view: 'settings', label: 'การตั้งค่าระบบ' },
      'การตั้งค่า': { view: 'settings', label: 'การตั้งค่าระบบ' },

      'council': { view: 'council', label: '10/10 HSM Quorum Council' },
      'สภา': { view: 'council', label: 'สภาฮาร์ดแวร์ 10/10 HSM Quorum' },
      'สภาฮาร์ดแวร์': { view: 'council', label: 'สภาฮาร์ดแวร์ 10/10 HSM Quorum' },

      'legal': { view: 'legal', label: 'Thai Statutory Safe Harbor (ETDA/PDPA)' },
      'law': { view: 'legal', label: 'Thai Statutory Safe Harbor (ETDA/PDPA)' },
      'pdpa': { view: 'legal', label: 'PDPA Compliance Suite' },
      'กฎหมาย': { view: 'legal', label: 'ศูนย์กฎหมายและพยานหลักฐาน ETDA/PDPA' },

      'studio': { view: 'studio', label: 'Studio & 18 Chambers Control Plane' },
      'chambers': { view: 'studio', label: '18 Sovereign Chambers Plane' },
      'สตูดิโอ': { view: 'studio', label: 'สตูดิโอและ 18 ห้องอธิปไตย' },
      'ห้องอธิปไตย': { view: 'studio', label: 'สตูดิโอและ 18 ห้องอธิปไตย' },

      'fusion': { view: 'fusion', label: 'Cognitive Fusion Matrix' },
      'ฟิวชั่น': { view: 'fusion', label: 'Cognitive Fusion Matrix' },

      'playback': { view: 'playback', label: 'Forensic Playback Engine' },
      'เล่นย้อนหลัง': { view: 'playback', label: 'เครื่องมือเล่นย้อนหลังทางนิติวิทยาศาสตร์' },

      'civilization': { view: 'civilization', label: 'Civilization World Intelligence' },
      'อารยธรรม': { view: 'civilization', label: 'ภูมิปัญญาอารยธรรมระดับโลก' },

      'heatmap': { view: 'heatmap', label: 'Sovereign Telemetry Heatmap' },
      'ฮีตแมป': { view: 'heatmap', label: 'แผนที่ความร้อนความปลอดภัย' },

      'analytics': { view: 'analytics', label: 'Security & Telemetry Analytics' },
      'การวิเคราะห์': { view: 'analytics', label: 'การวิเคราะห์ความปลอดภัย' },

      'audithistory': { view: 'audithistory', label: 'Forensic Audit History' },
      'ประวัติการตรวจสอบ': { view: 'audithistory', label: 'ประวัติการตรวจสอบนิติวิทยาศาสตร์' },

      'securitypipeline': { view: 'securitypipeline', label: 'Defense Security Pipeline' },
      'ไปป์ไลน์ความปลอดภัย': { view: 'securitypipeline', label: 'ไปป์ไลน์ระบบป้องกัน' },

      'briefing': { view: 'briefing', label: 'Executive Intelligence Briefing' },
      'สรุปย่อ': { view: 'briefing', label: 'สรุปย่อข่าวกรองอธิปไตย' },

      'sovereign-wallet': { view: 'sovereign-wallet', label: 'Sovereign Passkey & Hardware Key Wallet' },
      'กระเป๋าเงิน': { view: 'sovereign-wallet', label: 'กระเป๋าเงินและกุญแจฮาร์ดแวร์อธิปไตย' },
      'วอลเล็ต': { view: 'sovereign-wallet', label: 'กระเป๋าเงินและกุญแจฮาร์ดแวร์อธิปไตย' },
    };

    // Check View Navigation commands
    for (const [key, mapping] of Object.entries(commandMap)) {
      if (transcript.includes(key)) {
        playTone(620, 0.04);
        setPendingCommand({
          id: `cmd-nav-${key}-${Date.now()}`,
          transcript: rawTranscript,
          category: 'NAVIGATION',
          title: `Navigate to ${mapping.label}`,
          severity: 'STANDARD',
          description: `Switch the active interface viewport to ${mapping.label}.`,
          subsystem: `Viewport Navigation Router`,
          requiresManualConfirmation: requireManualConfirmAll,
          timeoutSeconds: 4,
          action: () => {
            onNavigate(mapping.view);
          }
        });
        return;
      }
    }

    // Capture telemetry snapshot trigger (English + Thai)
    if (
      transcript.includes('capture') ||
      transcript.includes('snapshot') ||
      transcript.includes('ถ่ายภาพ') ||
      transcript.includes('สแนปช็อต') ||
      transcript.includes('บันทึกสถานะ')
    ) {
      playTone(660, 0.04);
      setPendingCommand({
        id: `cmd-snapshot-${Date.now()}`,
        transcript: rawTranscript,
        category: 'TELEMETRY',
        title: 'Capture Hardware Telemetry Snapshot',
        severity: 'STANDARD',
        description: 'Take cryptographic hash snapshot of live thermal entropy and hardware registers.',
        subsystem: 'Chamber 09 / Telemetry Pipeline',
        requiresManualConfirmation: requireManualConfirmAll,
        timeoutSeconds: 4,
        action: () => {
          playAuditChime();
          onCaptureSnapshot();
        }
      });
      return;
    }

    // If recognized words did not match any known intent, show feedback
    playTone(400, 0.04);
    setLastCommand(`Unrecognized: "${rawTranscript}"`);
  }, [requireManualConfirmAll, confirmPendingCommand, cancelPendingCommand, onNavigate, onCaptureSnapshot, onNotifyEvent]);

  // Hook into browser SpeechRecognition with REAL-TIME interim results and dynamic language
  useEffect(() => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) return;

    const recognition = new SpeechRecognition();
    recognition.continuous = true;
    recognition.interimResults = true; // Enables real-time recognized text streaming
    recognition.lang = speechLanguage;

    recognition.onstart = () => setIsListening(true);
    recognition.onend = () => setIsListening(false);

    recognition.onerror = (event: any) => {
      console.warn("SpeechRecognition error or inactive", event);
      setIsListening(false);
    };

    recognition.onresult = (event: any) => {
      let interim = '';
      let final = '';

      for (let i = event.resultIndex; i < event.results.length; ++i) {
        const item = event.results[i];
        if (item.isFinal) {
          final += item[0].transcript;
        } else {
          interim += item[0].transcript;
        }
      }

      // Stream real-time recognized text as words are spoken
      if (interim) {
        setRealTimeTranscript(interim);
      }

      // When the utterance is final, process and stage for verification
      if (final) {
        setRealTimeTranscript(final);
        processTranscript(final);
      }
    };

    (window as any)._recognition = recognition;
  }, [processTranscript, speechLanguage]);

  const toggleListening = useCallback(() => {
    const recognition = (window as any)._recognition;
    if (!recognition) {
      // Toggle simulated listening indicator if browser doesn't have native Web Speech API
      setIsListening((prev) => !prev);
      return;
    }
    if (isListening) {
      recognition.stop();
      setRealTimeTranscript('');
    } else {
      try {
        setRealTimeTranscript('');
        recognition.lang = speechLanguage;
        recognition.start();
      } catch (err) {
        console.warn('SpeechRecognition start failed, toggling state', err);
        setIsListening(true);
      }
    }
  }, [isListening, speechLanguage]);

  // Simulated voice input with streaming effect
  const simulateVoiceCommand = useCallback((text: string, isStreaming = false) => {
    if (isStreaming) {
      setRealTimeTranscript('');
      setIsListening(true);
      let current = '';
      const words = text.split(' ');
      words.forEach((word, idx) => {
        setTimeout(() => {
          current += (idx > 0 ? ' ' : '') + word;
          setRealTimeTranscript(current);
          if (idx === words.length - 1) {
            setTimeout(() => {
              processTranscript(text);
            }, 300);
          }
        }, (idx + 1) * 180);
      });
    } else {
      setRealTimeTranscript(text);
      processTranscript(text);
    }
  }, [processTranscript]);

  // Backward compatibility getter for pendingConfirmation
  const pendingConfirmation = pendingCommand && pendingCommand.category === 'SOVEREIGN_DIRECTIVE' ? {
    id: pendingCommand.id,
    transcript: pendingCommand.transcript,
    commandType: (
      pendingCommand.title.includes('Freeze') ? 'FREEZE_STATE' :
      pendingCommand.title.includes('Zeroization') ? 'ZEROIZE_KEYS' :
      pendingCommand.title.includes('Quarantine') ? 'QUARANTINE_CHAMBER' :
      pendingCommand.title.includes('Phoenix') ? 'RECONSTITUTE_QUORUM' :
      pendingCommand.title.includes('Seal') ? 'SOVEREIGN_SEAL' : 'COURT_DOSSIER'
    ) as PendingSovereignCommand['commandType'],
    title: pendingCommand.title,
    severity: pendingCommand.severity as 'CRITICAL' | 'HIGH',
    description: pendingCommand.description,
    impact: pendingCommand.impact || '',
    subsystem: pendingCommand.subsystem,
    action: pendingCommand.action
  } : null;

  return {
    isListening,
    realTimeTranscript,
    lastCommand,
    toggleListening,
    pendingCommand,
    pendingConfirmation, // backward compatibility
    confirmPendingCommand,
    cancelPendingCommand,
    simulateVoiceCommand,
    requireManualConfirmAll,
    setRequireManualConfirmAll,
    speechLanguage,
    setSpeechLanguage,
  };
};
